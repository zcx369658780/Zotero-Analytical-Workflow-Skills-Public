function mydata = load_distdata(max_sigmau)
%% 2023年12月6日 地理距离数据读取函数
%% 算法描述：读取地理距离的数据，然后转换成迁移成本。
%% 这里假设两个省份之间，距离越远迁移成本越高，最高为max_sigmau。
	global N_prov;
	mydata2 = xlsread("中国各省省会地理距离矩阵.xlsx");
	maxdist = max(mydata2, [], 'all');
	mydata = mydata2/maxdist * max_sigmau;
