function results = HANK_2ASSETS_HJB(param, grid, num, CHIh, results, show_result)
	ga		= 	param.ga;
	alphap	= 	param.alphap;
	alphal	= 	param.alphal;
	rho		=	param.rho;
	alphal	=	param.alphal;
	Cmin	=	0;
	frisch_l	=	param.frisch_l;

	I		=	grid.I;
	bmin	=	grid.bmin;
	bmax	=	grid.bmax;
	J		=	grid.J;
	ahmin	=	grid.amin;
	ahmax	=	grid.amax;
	Nz		=	grid.Nz;
	zmin	=	grid.zmin;
	zmax	=	grid.zmax;
	z		=	grid.z;
	la_mat	=	grid.la_mat;
	maxit	=	num.maxit;
	crit	=	num.crit;
	Delta	=	num.Delta;
	maxiter	=	num.maxiter;
	
	rb		=	results.rb;
	rah		=	results.rah;
	w		=	results.w;
	rb_gap	=	results.rb_gap;
	tau		=	results.tau;
	Tt	=	results.Tt;
	
	Ct_1 = results.Ct;
	Aht_1	=	results.At;
	Bt_1	=	results.Bt;
	Lt_1	=	results.Lt;


	convergent = 0; % 收敛时改成1




	alphac=1;

	b = linspace(bmin,bmax,I); 
	db = (bmax-bmin)/(I-1);
	ah = linspace(ahmin,ahmax,J); 
	dah = (ahmax-ahmin)/(J-1);
	zmean = (zmax+zmin)/2;
	dz = (zmax-zmin)/(Nz-1);
	bbb = zeros(I,J,Nz); 
	aaah = zeros(I,J,Nz); 
	zzz = zeros(I,J,Nz);
	for nz = 1:Nz
			for j = 1:J
				for i = 1:I
					bbb(i,j,nz) = b(i);
					aaah(i,j,nz) = ah(j);
					zzz(i,j,nz) = z(nz);
				end
			end
	end
	Bswitch = [
	speye(I*J)*la_mat(1,1), speye(I*J)*la_mat(1,2);
	speye(I*J)*la_mat(2,1), speye(I*J)*la_mat(2,2)];
	VbF = zeros(I,J,Nz);
	VbB = zeros(I,J,Nz);
	VahF = zeros(I,J,Nz);
	VahB = zeros(I,J,Nz);
	VafF = zeros(I,J,Nz);
	VafB = zeros(I,J,Nz);
	C = zeros(I,J,Nz);
	Rah = zeros(I,J,Nz);
	Raf = zeros(I,J,Nz);
	updiag = zeros(I*J,Nz);
	lowdiag = zeros(I*J,Nz);
	centdiag = zeros(I*J,Nz);
	rb_neg = rb + rb_gap;
	Rb = rb.*(bbb>=0) + rb_neg.*(bbb<0); 
	raah = rah.*(1 - 0.1*(ahmax./ah).^(-9));
	for nz = 1:Nz
			for j = 1:J
				for i = 1:I
					Rah(i,j,nz) = raah(j);
				end
			end
	end
	options=optimset('Display','off');   
	tempMat = Rah.*raah + Rb.*bbb + Tt;
	min_Household_Income = min(tempMat,[],'all');
	if show_result==1
		disp(['当前省份家户参数为： bmax=',num2str(bmax), ', amax=',num2str(ahmax),', w=',num2str(w),', ra=',num2str(rah),', Tt=',num2str(Tt)]);
		disp(['——当前省份为：',results.prvname,', 厂商参数为： Zt=',num2str(results.Zt), ', Kt=',num2str(results.Kt), '/',num2str(results.Kt0),', alpha=',num2str(results.alpha)]);

		disp(['——家户最低收入为：', num2str(min_Household_Income)]);
	end


	for nz = 1:Nz
			for j = 1:J
				for i = 1:I
					params = [alphac,alphal, tau, w, zzz(i,j,nz), frisch_l, tempMat(i,j,nz), ga]; 
					myfun = @(l) lab_solve2(l, params); 
					x0 = ((1-tau)*w*zzz(i,j,nz))^(frisch_l*(1-ga)/(1+ga*frisch_l)); 
					[l0j,fval,exitflag] = fzero(myfun,x0,options); 
					l0(i,j,nz)= l0j;
				end
			end
	end
	c0 = (1-tau).*w.*zzz.*l0 + Rb.*bbb + Tt; 
	v02 = (c0.^(1-ga)./(1-ga) * alphac - alphal*l0.^(1+1/frisch_l)./(1+1/frisch_l))./ rho;
	v = v02; l = l0;
	for n=1:maxit
		V = v;
		VbF(1:I-1,:,:) = (V(2:I,:,:)-V(1:I-1,:,:))/db;
		VbF(I,:,:) = alphac*((1-tau).*w.*zzz(I,:,:).*l0(I,:,:) + Tt + Rb(I,:,:).*bbb(I,:,:)).^(-ga);
		VbB(2:I,:,:) = (V(2:I,:,:)-V(1:I-1,:,:))/db;
		VbB(1,:,:) = alphac*((1-tau).*w.*zzz(1,:,:).*l0(1,:,:) + Tt + Rb(1,:,:).*bbb(1,:,:)).^(-ga);
		VahF(:,1:J-1,:) = (V(:,2:J,:)-V(:,1:J-1,:))/dah;
		VahB(:,2:J,:) = (V(:,2:J,:)-V(:,1:J-1,:))/dah;
		VahF(:,J,:) = zeros(I,1,Nz);
		VahB(:,1,:) = zeros(I,1,Nz);
		C_B = max(VbB/alphac,10^(-6)/alphac).^(-1/ga);
		C_F = max(VbF/alphac,10^(-6)/alphac).^(-1/ga);
		C_0 = (1-tau)*w.*zzz.*l0 + Tt + Rb.*bbb;
		l_B = (max(VbB,10^(-6))*(1-tau)*w.*zzz/alphal).^frisch_l;
		l_F = (max(VbF,10^(-6))*(1-tau)*w.*zzz/alphal).^frisch_l;
		sc_B = (1-tau)*w.*zzz.*l_B + Tt + Rb.*bbb - C_B;
		sc_F = (1-tau)*w.*zzz.*l_F + Tt + Rb.*bbb - C_F;
		Ic_B = (sc_B < -10^(-12));
		Ic_F = (sc_F > 10^(-12)).*(1 - Ic_B);
		Ic_0 = 1 - Ic_F - Ic_B;
		C = C_F.*Ic_F + C_B.*Ic_B + C_0.*Ic_0; 
		l = l_F.*Ic_F + l_B.*Ic_B + l0.*Ic_0; 
		u = alphac*C.^(1-ga)./(1-ga) - alphal*l.^(1+1/frisch_l)./(1+1/frisch_l);
		dhBB = HANK3_FOC(results,CHIh,VahB,VbB,aaah,0);
		dhBF = HANK3_FOC(results,CHIh,VahF,VbB,aaah,0);
		dhFB = HANK3_FOC(results,CHIh,VahB,VbF,aaah,0);
		dhFF = HANK3_FOC(results,CHIh,VahF,VbF,aaah,0);
		dh_B = (dhBF>0).*dhBF + (dhBB<0).*dhBB;
		dh_B(:,1,:) = (dhBF(:,1,:)>10^(-12)).*dhBF(:,1,:);
		dh_B(:,J,:) = (dhBB(:,J,:)<-10^(-12)).*dhBB(:,J,:);
		dh_B(1,1,:) = max(dh_B(1,1,:),0);
		dh_F = (dhFF>0).*dhFF + (dhFB<0).*dhFB;
		dh_F(:,1,:) = (dhFF(:,1,:)>10^(-12)).*dhFF(:,1,:);
		dh_F(:,J,:) = (dhFB(:,J,:)<-10^(-12)).*dhFB(:,J,:);
		sdh_B = (-dh_B - HANK3_cost(results,CHIh,dh_B,aaah,0));
		sdh_F = (-dh_F - HANK3_cost(results,CHIh,dh_F,aaah,0));
		Idh_F = (sdh_F > 10^(-12));
		Idh_B = (sdh_B < -10^(-12)).*(1 - Idh_F);
		Idh_B(1,:,:) = 0; 
		Idh_F(I,:,:) = 0; Idh_B(I,:,:) = 1;
		Idh_0 = 1 - Idh_B - Idh_F;
		X = - Ic_B.*sc_B/db - Idh_B.*sdh_B/db ;
		Y = Ic_B.*sc_B/db + Idh_B.*sdh_B/db - Ic_F.*sc_F/db - Idh_F.*sdh_F/db;
		Z = Ic_F.*sc_F/db + Idh_F.*sdh_F/db;
		for nz = 1:Nz
				for j = 1:J
					for i = 1:I
						centdiag(i+(j-1)*I,nz) = Y(i,j,nz);
					end
				end
		end
		for nz = 1:Nz
				for j = 1:J
					for i = 1:I-1
						lowdiag(i+(j-1)*I,nz) = X(i+1,j,nz);
					end
					for i = I:I
						lowdiag(i+(j-1)*I,nz) = 0;
					end
				end
		end
		for nz = 1:Nz
				for j = 1:J
					for i = 1:1
						updiag(i+(j-1)*I,nz) = 0;
					end
					for i = 2:I
						updiag(i+(j-1)*I,nz) = Z(i-1,j,nz);
					end
				end
		end
		for nz=1:Nz
			BBi{nz}=spdiags(centdiag(:,nz),0,I*J,I*J)+spdiags([updiag(:,nz);0],1,I*J,I*J)+spdiags([lowdiag(:,nz);0],-1,I*J,I*J);
		end
		BB = [BBi{1}, sparse(I*J,I*J); sparse(I*J,I*J), BBi{2}];
		BB2max = max(sum(BB,2));
		dhB = Idh_B.*dhBB + Idh_F.*dhFB;
		dhF = Idh_B.*dhBF + Idh_F.*dhFF;
		MhB = min(dhB,0);
		MhF = max(dhF,0) + Rah.*aaah;
		MhB(:,J,:) = dhB(:,J,:) + Rah(:,J,:).*ahmax;
		MhF(:,J,:) = 0;
		chih = -MhB/dah;
		yyh = (MhB - MhF)/dah;
		zetah = MhF/dah;
		for nz = 1:Nz
				for i = 1:I
					for j = 1:J
						centdiagh(i+(j-1)*I,nz) = yyh(i,j,nz);
					end
				end
		end
		for nz = 1:Nz
				for i = 1:I
					for j = 1:J-1
						lowdiagh(i+(j-1)*I,nz) = chih(i,j+1,nz);
					end
					for j = J:J
						lowdiagh(i+(j-1)*I,nz) = 0;
					end
				end
		end
		for nz = 1:Nz
				for i = 1:I
					for j = 1:1
						updiagh(i+(j-1)*I,nz) = 0;
					end
					for j = 2:J
						updiagh(i+(j-1)*I,nz) = zetah(i,j-1,nz);
					end
				end
		end
		for nz=1:Nz
			AAHi{nz}=spdiags(centdiagh(:,nz),0,I*J,I*J)+spdiags([updiagh(:,nz);0],I,I*J,I*J)+spdiags([lowdiagh(:,nz);0],-I,I*J,I*J);
		end
		AAH = [AAHi{1}, sparse(I*J,I*J); sparse(I*J,I*J), AAHi{2}];
		AAH2max = max(sum(AAH,2));
		Bswitch2max = max(sum(Bswitch,2));
		A = BB + AAH  + Bswitch;
		A2max = max(abs(sum(A,2)));
		if A2max > num.homecrit
			if show_result==1
			disp(['Improper Transition Matrix, BB, AH, Bswitch; A2 error = ', num2str(BB2max), ', ',num2str(AAH2max), ', ',num2str(Bswitch2max), '; ',num2str(A2max), '.'])
			end
			break
		end
		B = (1/Delta + rho)*speye(I*J*Nz) - A;
		u_stacked = reshape(u,[I*J*Nz,1]);
		V_stacked = reshape(V,[I*J*Nz,1]);
		vec = u_stacked + V_stacked/Delta;
		V_stacked = B\vec; 
		V = reshape(V_stacked,[I,J,Nz]);
		Vchange = V - v;
		v = V;
		dist(n) = max(abs(Vchange), [] , 'all');
		if dist(n)<crit
			convergent = 1;
			if show_result==1
				disp("HJB Converged!")
			end
			break
		end
		if n ==maxit
			if show_result==1
				disp("HJB NOT Converged!")
			end
		end
	end
	dh = Idh_B.*dh_B + Idh_F.*dh_F;
	s = (1-tau)*w*zzz.*l + Rb.*bbb + Tt - Cmin  - dh - HANK3_cost(results,CHIh,dh,aaah,0) - C;
	mh = dh + Rah.*aaah;
	X = -min(s,0)/db;
	Y = min(s,0)/db - max(s,0)/db;
	Z = max(s,0)/db;
		for nz = 1:Nz
				for j = 1:J
					for i = 1:I
						centdiag(i+(j-1)*I,nz) = Y(i,j,nz);
					end
				end
		end
		for nz = 1:Nz
				for j = 1:J
					for i = 1:I-1
						lowdiag(i+(j-1)*I,nz) = X(i+1,j,nz);
					end
					for i = I:I
						lowdiag(i+(j-1)*I,nz) = 0;
					end
				end
		end
		for nz = 1:Nz
				for j = 1:J
					for i = 1:1
						updiag(i+(j-1)*I,nz) = 0;
					end
					for i = 2:I
						updiag(i+(j-1)*I,nz) = Z(i-1,j,nz);
					end
				end
		end
		for nz=1:Nz
			BBi{nz}=spdiags(centdiag(:,nz),0,I*J,I*J)+spdiags([updiag(:,nz);0],1,I*J,I*J)+spdiags([lowdiag(:,nz);0],-1,I*J,I*J);
		end
	BB = [BBi{1}, sparse(I*J,I*J); sparse(I*J,I*J), BBi{2}];
	chih = -min(mh,0)/dah;
	yyh = min(mh,0)/dah - max(mh,0)/dah;
	zetah = max(mh,0)/dah;
		for nz = 1:Nz
				for i = 1:I
					for j = 1:J
						centdiagh(i+(j-1)*I,nz) = yyh(i,j,nz);
					end
				end
		end
		for nz = 1:Nz
				for i = 1:I
					for j = 1:J-1
						lowdiagh(i+(j-1)*I,nz) = chih(i,j+1,nz);
					end
					for j = J:J
						lowdiagh(i+(j-1)*I,nz) = 0;
					end
				end
		end
		for nz = 1:Nz
				for i = 1:I
					for j = 1:1
						updiagh(i+(j-1)*I,nz) = 0;
					end
					for j = 2:J
						updiagh(i+(j-1)*I,nz) = zetah(i,j-1,nz);
					end
				end
		end
		for nz=1:Nz
			AAHi{nz}=spdiags(centdiagh(:,nz),0,I*J,I*J)+spdiags([updiagh(:,nz);0],I,I*J,I*J)+spdiags([lowdiagh(:,nz);0],-I,I*J,I*J);
		end
		AAH = [AAHi{1}, sparse(I*J,I*J); sparse(I*J,I*J), AAHi{2}];
	A = BB + AAH + Bswitch;
	M = I*J*Nz;
	AT = A';
	vec = zeros(M,1);
	iFix = floor(0.37*M);
	vec(iFix) = 0.007;
	AT(iFix,:) = [zeros(1,iFix-1),1,zeros(1,M-iFix)];
	g_stacked = AT\vec;
	g_sum = g_stacked'*ones(M,1)*db*dah;
	g_stacked = g_stacked./g_sum;
	g(:,:,1) = reshape(g_stacked(1:I*J),[I,J]);
	g(:,:,2) = reshape(g_stacked(I*J+1:I*J*2),[I,J]);
	sumg = sum(g*dah*db , 'all');
	maxg = max(abs(g), [] , 'all');
	Lt = sum(zzz.*l.*g*dah*db , 'all');
	Bt = sum(bbb.*g*dah*db , 'all');
	Bt_pos = sum(bbb.*(bbb>=0).*g*dah*db, 'all');
	Bt_neg = abs( sum(bbb.*(bbb<0).*g*dah*db, 'all') );
	Aht = sum(aaah.*g*dah*db, 'all');
	Bdotres = sum(((1-tau)*w*zzz.*l + Rb.*bbb + Tt - Cmin  - dh - HANK3_cost(results,CHIh,dh,aaah,0) - C).*g*dah*db , 'all');
	Income = (1-tau)*w*zzz.*l + Rb.*bbb + Tt - Cmin  - dh - HANK3_cost(results,CHIh,dh,aaah,0);
	Ct = sum(C.*g*dah*db, 'all');
		MPC = zeros(I,J,Nz);
		for nz = 1:Nz
			for j = 1:J
					for i = 1:(I-1)
						MPC(i,j,nz) = C(i+1,j,nz) - C(i,j,nz);
					end
						MPC(I,j,nz) = MPC(I-1,j,nz);
			end
		end
	St = sum(s.*g*dah*db, 'all');
	AhTax = Aht*rah - sum(aaah.*raah.*g*dah*db, 'all');
	Ut	=	sum(u.*g*db*dah, 'all');
	Borrow = sum(g.*(bbb<0)*dah*db, 'all'); 
	Borrowint = sum(bbb.*rb_gap.*g.*(bbb<0)*dah*db, 'all'); 
	CHI_H = sum(g.*HANK3_cost(results,CHIh,dh,aaah,0)*dah*db, 'all'); 
	CHI_F = 0; 
	uc = C.^(-ga) * alphac;
	UC = sum(uc.*g*db*dah, 'all');

	if show_result==1
		disp(['————家户计算结果: Ct,Lt,Bt_pos,Bt_neg,Aht = ', num2str(Ct), ', ', num2str(Lt), ', ', num2str(Bt_pos), ', ', num2str(Bt_neg), ', ', num2str(Aht)]);
		disp(['————目前的wjt取值为：',num2str(results.wjt)])
	end


	%results.bbb = bbb;
	%results.zzz = zzz;
	results.aaah = aaah;
	%results.a = ah;
	results.rb_neg = rb_neg;
	%results.b = b;
	%results.z = z;
	gg = g*db*dah;
	results.g = gg;
	results.C = C.*g*dah*db;
	%results.Income = Income;
	results.min_Household_Income = min_Household_Income;
	%results.MPC = MPC;
	%results.u = u;
	results.l = zzz.*l.*g*dah*db;
	%results.s = s;
	%results.V = V;
	results.Lt = Lt;
	results.Bt = Bt;
	results.Bt_pos = Bt_pos;
	results.Bt_neg = Bt_neg;
	results.Ut = Ut;
	results.At = Aht;
	results.Ct = Ct;
	results.Ct_1 = Ct_1;
	results.St = St;
	results.AtTax = AhTax;
	results.Borrow = Borrow;
	results.Borrowint = Borrowint;
	results.CHI_H = CHI_H;
	results.CHI_F = CHI_F;
	results.Bdotres = Bdotres;
	results.UC_new = UC;
	results.At_1	=	Aht_1;
	results.Bt_1	=	Bt_1;
	results.Lt_1	=	Lt_1;
	results.Atdot	=	Aht - Aht_1;
	results.Btdot	=	Bt - Bt_1;
	results.Ltdot	=	Lt - Lt_1;
	
	results.gini_bt = HANK_gini(0, gg, bbb, aaah, 'Bt');
	results.gini_aht = HANK_gini(0, gg, aaah, aaah, 'Bt');
	results.gini_ct = HANK_gini(0, gg, C, aaah, 'Bt');
	results.gini_lt = HANK_gini(0, gg, zzz.*l, aaah, 'Bt');
	results.gini_income = HANK_gini(0, gg, Income, aaah, 'Bt');
	results.convergent = convergent;

end
