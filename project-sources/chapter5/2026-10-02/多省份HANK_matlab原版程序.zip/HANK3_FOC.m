function d = HANK3_FOC(results,paramchi,pa,pb,a,foreign)
chi0 = paramchi.chi0;
chi1 = paramchi.chi1;
fixcost = paramchi.fixcost;
fixcost2 = paramchi.fixcost2;
a_bar = paramchi.a_bar;
PFt = 1;
Pt = 1;
et = 1;
price = PFt*et/Pt;

if foreign == 1
	%d = (min(pa./pb - 1 + chi0*price,0) +  max(pa./pb - 1 - chi0*price,0)).*a/chi1;
	%chi1 = chi1 + fixcost;
	chi0 = chi0 + fixcost2;
	%chi1 = chi1 + fixcost2;
	d = (min(pa./pb - 1 + chi0*price,0) +  max(pa./pb - 1 - chi0*price,0)).*a/chi1;
else
	d = (min(pa./pb - 1 + chi0,0) +  max(pa./pb - 1 - chi0,0)).*a/chi1;
end

end