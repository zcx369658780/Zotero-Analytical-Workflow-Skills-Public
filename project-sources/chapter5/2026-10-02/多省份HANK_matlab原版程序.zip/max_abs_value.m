function result = max_abs_value(var_vec)  
    % 找到最大值和最小值  
    maxValue = max(var_vec, [], 'all');  
    minValue = min(var_vec, [], 'all');  
      
    % 计算绝对值  
    maxAbsValue = abs(maxValue);  
    minAbsValue = abs(minValue);  
      
    % 返回绝对值较高的一个  
    if maxAbsValue > minAbsValue  
        result = maxValue;  
    else  
        result = minValue;  
    end  
end