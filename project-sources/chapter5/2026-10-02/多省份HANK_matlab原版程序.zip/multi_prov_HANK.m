function [IRF, st] = multi_prov_HANK(shocks, shockname, styear, onlySS)
%% 2023年12月6日 多省份神HANK的求解程序
%%% 主要用途为调用其他子函数完成多省份神经网络HANK模型的计算
%%% 返回的结果就是模型模拟结果。
%%% 2024年3月16日 新推导了模型结构，暂时去掉
global Ncores;
global myfontsize;
global N_prov; N_prov = 31;
warning('off');
global Ncores;
global myfontsize;
global N_prov; N_prov = 31;
warning('off');




nst = styear-2008;
% 读取稳态数据
	st = multi_prov_HANK_12sts(nst,0);

if onlySS==1
% 检查各省的稳态分布
	Plot_multiprv_g(st, N_prov, "多省份稳态分布图_test");
	error('st test!!')
end

IRFfile = strcat('多省份IRF_',num2str(styear),'_',shockname,'.mat');
% 读取数据，判断当前剩余计算任务。
if exist(IRFfile) == 2
	disp(['发现稳态数据文件: ', IRFfile,', 读取稳态数据...'])
	temp2 = struct2cell(load(IRFfile,'IRF'));
	IRF = temp2{1};
	%save(IRFfile, 'IRF', '-v7.3');
else
	for j = 1:shocks{1}.NIRFs
		T = shocks{1}.T;
		disp(" ")
		disp(" ")
		disp(strcat("——————当前进度：", num2str(j), "/",num2str(shocks{1}.NIRFs)))
		IRF{j} = mpHANK_shock_2000(st, shocks{j},T);
	end
	save(IRFfile, 'IRF', '-v7.3');
end


