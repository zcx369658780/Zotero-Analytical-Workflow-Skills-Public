function results = HANK_firm(param, grids, results, steadystate, show_result)
%% 2023年12月6日 多省份HANK模型的企业部门求解
%% 算法说明：暂时只会根据输入的劳动和资本存量来计算产出、工资。
	
	epsilon = param.epsilon;
	theta = param.theta;
	delta = param.delta;
	corptau = results.corptau;
	Lt = results.Lt_supply; % 
	%if steadystate == 1
	%	Kt = results.Kt0; % 求解稳态时，资产固定为外生值
	%	results.GovInv = Kt - results.Kt_supply;
	%else
		Kt = results.Kt_supply + results.GovInv; % 新算法，添加资产外溢效应
	%end
	alpha = results.alpha; %
	Zt = results.Zt; % 技术水平，暂时没有很好的数据来源。
	pit = results.pit; % 本省的通胀率
	
	Kt_1 = results.Kt; % 上一期的变量记录，下同
	Lt_1 = results.Lt;
	Yt_1 = results.Yt;
	Zt_1 = results.Zt_1;
	pit_1 = results.pit_1;
	rk = results.rk;
	wjt = results.wjt;
	
	
	% 首先计算产出
	Yt = Zt * Kt^alpha * Lt^(1-alpha);
	
	% NKPC曲线
	mstar = 1 - 1/epsilon; % 中间品厂商替代弹性，目标边际成本
	if steadystate == 1 % 求解稳态的时候
		mt = (rk - (Zt_1-Zt)/Zt - alpha*(Kt_1-Kt)/Kt -(1-alpha)*(Lt_1-Lt)/Lt)*pit*theta/epsilon + mstar - (pit-pit_1)*theta/epsilon;
	else % 求解冲击响应的时候，用稳态值计算差额
		mt = (rk - (results.Zt_ss-Zt)/Zt - alpha*(results.Kt_ss-Kt)/Kt -(1-alpha)*(results.Lt_ss-Lt)/Lt)*pit*theta/epsilon + mstar - (pit-results.pit_ss)*theta/epsilon;
	end
	%mt = 1/Zt * (rk/alpha)^alpha * (results.wjt/(1-alpha))^(1-alpha);
	% 计算厂商收益率
	Ydot = Yt - Yt_1;
	KNratio = Kt/Lt;
	wt0 = mt*(1-alpha)*Zt*KNratio^alpha; % 劳动回报率
	KYratio = Kt/Yt;
	rk = mt*alpha/KYratio; % 资本租金
	Thetat = theta/2*pit^2*Yt; % 总价格调整成本
	It = Kt - Kt_1 + delta*Kt; % 投资
	PIt = (1-mt)*Yt - Thetat; % 净利润
	if (PIt < 0)
		PIt = 0; % 限制范围
	end
	Corptax = PIt*corptau; % 企业纳税额
	divrate = PIt*(1-corptau)/Kt; % 利润分红率
	ra0 = rk - delta + divrate; % 最终固定资产回报率
	% 限制ra的范围，防止模型在收敛途中崩溃
	% 稳态时不能出现边界值
		if ra0 > grids.ramax
			Corptax = Corptax + (ra0-grids.ramax)*Kt;
			ra = grids.ramax;
		elseif ra0<grids.ramin
			Corptax = Corptax - (grids.ramin-ra0)*Kt;
			ra = grids.ramin;
		else
			ra = ra0;
		end
		if wt0 < grids.wjtmin
			Corptax = Corptax - (grids.wjtmin-wt0)*Lt; % 工资太低就用税收抵扣
			wjt = grids.wjtmin;
		elseif wt0 > grids.wjtmax
			Corptax = Corptax + (wt0-grids.wjtmax)*Lt;
			wjt = grids.wjtmax;
		else
			wjt = wt0;
		end
	results.GVratio = results.GovInv/ results.Kt;
	if show_result==1
		disp(strcat('————',results.prvname,'国资比，alpha，企业的Zt。——Yt/Y0, Kt/K0, Lt/N, mc。——ra, wjt =', num2str(results.GVratio), ' , ', num2str(results.alpha), ', ', num2str(Zt), '。——', num2str(Yt),'/',num2str(results.Yt0), ', ', num2str(Kt),'/',num2str(results.Kt0), ', ', num2str(Lt),'/',num2str(results.N), ', ', num2str(mt), '。——', num2str(ra0), ', ', num2str(wt0)));
	end

	% 保存结果
	results.wjt = wjt; % wjt是一个省的工资率，家户的工资率是results.w
	results.Yt = Yt;
	results.Yt_1 = Yt_1;
	results.ra = ra;
	results.Kt_1 = Kt;
	results.Kt = Kt;
	results.Lt_1 = Lt;
	results.Lt = Lt;
	results.Ct_total = results.Ct * results.N;
	results.Zt_1 = Zt;
	results.Zt = Zt;
	results.pit_1 = pit;
	results.mt = mt;
	results.rk = rk;
	results.Govinc = Corptax + Lt*results.tau + results.AtTax + results.GovInv*ra - results.Tt;% 省政府的收入
	results.Corptax = Corptax;
	results.Thetat = Thetat;
	results.KNratio = KNratio;
	