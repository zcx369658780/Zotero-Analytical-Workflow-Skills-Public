function [results, GDP_vec] = HANK_mp_1turn(results_temp, param, grids, num, CHI, sigmau_MAT, N_prov, show_result, steady_state)
% 根据给定的数据，计算一轮的各省份数据。主要用于计算近似偏导。
	% 计算劳动厌恶系数矩阵
	phi_MAT = zeros(N_prov,N_prov); % 劳动相对厌恶系数矩阵，不进入HJB
	for i = 1:N_prov
		for j = 1:N_prov
			% 效用函数中，第i个省份的人去第j个省份工作时的劳动厌恶系数。目标地点人均GDP越高则这个厌恶系数越低，代表人们喜欢去发达地区工作。
			%phi_MAT(j,i) = 1 - param.max_phi*(results{j}.Yt/results{j}.Lt - results{i}.Yt/results{i}.Lt)/results{j}.Yt/results{j}.Lt; 
			% 新算法，phi值最高为1+max_phi，最低为1-max_phi
			phi_MAT(j,i) = 1 + param.max_phi*(results_temp{j}.Yt/results_temp{j}.Lt - results_temp{i}.Yt/results_temp{i}.Lt)/(results_temp{j}.Yt/results_temp{j}.Lt + results_temp{i}.Yt/results_temp{i}.Lt); 
		end
	end
	% 计算每个省份的家户部门，粗略算出当前轮次的总产出
		for i = 1:N_prov
			results{i} = HANK_2ASSETS_HJB(param, grids{i}, num, CHI, results_temp{i}, show_result);
		end

	if show_result == 1
		disp(['Phi_MAT的最小/大值为：', num2str(min(phi_MAT,[],'all')),'/ ',num2str(max(phi_MAT,[],'all'))])
	end
	% 计算每个省份的劳动流向，然后更新每个省的总劳动供给
	% 2024年6月5日更新：保存劳动力流向矩阵，方面画图。
	Lt_mat = Lt_seperate(results, param, phi_MAT, sigmau_MAT, N_prov);
		for i = 1:N_prov
			results{i}.Lt_supply = sum(Lt_mat(i,:), 'all');
		end
	results{i}.Lt_mat = Lt_mat;
	% 计算每个省份外溢的资本存量和收益率，注意国有资本不参与这个市场
		tempKt = 0; tempra = 0;
		for i = 1:N_prov
			tempKt = tempKt + results{i}.inter_prv_ratio*results{i}.At*results{i}.N;
			tempra = tempra + results{i}.inter_prv_ratio*results{i}.ra;
		end
		%disp(["tempra = ",num2str(tempra)])
		for i = 1:N_prov % 假设每个家户会平均地购买所有其他省份的资产
			results{i}.Kt_supply = 1/(N_prov-1) * (tempKt - results{i}.inter_prv_ratio*results{i}.At*results{i}.N);
		end
		for i = 1:N_prov
		%disp(["results{i}.ra  = ",num2str(results{i}.ra )])
			results{i}.rah = (1-results{i}.inter_prv_ratio)*results{i}.ra + 1/(N_prov-1) * results{i}.inter_prv_ratio*(tempra - results{i}.inter_prv_ratio*results{i}.ra);
		end
		

	% 计算每个省份的企业部门
		for i = 1:N_prov
			results{i} = HANK_firm(param, grids{i}, results{i}, steady_state, show_result);
		end

	% 计算当前的平均工资
		wt_vec = wage_caculate(results, param, phi_MAT, sigmau_MAT, N_prov);
		for i = 1:N_prov
			results{i}.w = wt_vec(i); % 家户下一期使用的工资率
		end

		GDP_vec = zeros(N_prov,1);
		for i = 1:N_prov
			GDP_vec(i) = results{i}.Yt;
		end

	% 计算全局税收和中央银行决策
		results{1}.GovSurplus = 0;
		for i = 1:N_prov
			results{i}.it = param.istar + param.rho_pi * results{1}.totalpit + results{1}.epsilon_pi;
			results{i}.rb = results{i}.it - results{1}.totalpit;
			results{1}.GovSurplus = results{1}.GovSurplus + results{i}.Govinc - results{i}.Bt*results{i}.rb*results{i}.N;
		end
		






