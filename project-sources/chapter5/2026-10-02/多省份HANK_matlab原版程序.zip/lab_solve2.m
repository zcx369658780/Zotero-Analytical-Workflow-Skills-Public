function eq = lab_solve2(l,params)
alphac = params(1);
alphal = params(2);
tau = params(3);
w = params(4);
zzz = params(5);
frisch_l = params(6);
tempMat = params(7);
ga = params(8);

eq = l - (alphac/alphal*(1-tau)*w*zzz)^frisch_l * (l*(1-tau)*w*zzz + tempMat)^(-ga*frisch_l);