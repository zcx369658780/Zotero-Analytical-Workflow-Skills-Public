function wmat = init_weight_matrix(wages, threshold)
% 初始化外出务工权重矩阵的程序。
% 输入：每个省份对应的工资率序列，还有判定去打工的最低外省工资比例
% 输出：初始化后的权重矩阵。
% 算法说明：对每个省来说，初始的务工权重等同于平均地去所有收入不低于本省70%水平的地区。这样设定，可以避免最富有的省份完全没有人外出务工，从而必须重新写一个HJB程序。

	nprov = length(wages);
	wmat2 = zeros(nprov, nprov);
	for i = 1:nprov
		for j = 1:nprov
			if i~=j && wages(i)*threshold < wages(j)
				wmat2(i,j) = 1;
			end
		end
	end
	wmat = normalize_weight_matrix(wmat2);
