function [results, GDP_vec, finish] = HANK_mp_1eq(results_temp, param, grids, num, CHI, sigmau_MAT, N_prov, reg_threshold, show_result, steady_state)
% 计算临时稳态值
	tKNratio = 3*ones(N_prov,1);
	finish=0;
	results = results_temp;

for j = 1:num.max3iter
	[results, GDP_vec] = HANK_mp_1turn(results, param, grids, num, CHI, sigmau_MAT, N_prov, show_result, steady_state);

	NKrationgap = zeros(N_prov,1);Ytgap = zeros(N_prov,1);convergent_total=0;
	maxra=0;minra=0;maxraprvs = {}; minraprvs= {};
	maxwjt=0;minwjt=0;maxwjtprvs = {}; minwjtprvs= {};
	for i = 1:N_prov
		if results{i}.ra == grids{i}.ramax
			maxra = maxra+1;maxraprvs{end+1} = results{i}.prvname;
		elseif results{i}.ra == grids{i}.ramin
			minra = minra+1;minraprvs{end+1} = results{i}.prvname;
		end
		if results{i}.wjt == grids{i}.wjtmax
			maxwjt = maxwjt+1;maxwjtprvs{end+1} = results{i}.prvname;
		elseif results{i}.wjt == grids{i}.wjtmin
			minwjt = minwjt+1;minwjtprvs{end+1} = results{i}.prvname;
		end
		
	end
	for i = 1:N_prov
	% 判定是否运算出错
		if isreal(results{i}.Yt) == 0
			error('————Programme Break!')
		end
		NKrationgap(i) = abs(results{i}.KNratio/tKNratio(i) - 1);
		Ytgap(i) = abs(results{i}.Yt/results{i}.Yt_1 - 1);
		convergent_total = convergent_total+results{i}.convergent;
	end
	[maxKNratiogap,maxKNprv] = max(NKrationgap, [], 'linear');
	[maxYtgap,maxYgapprv] = max(Ytgap, [], 'linear');
	%disp(strcat(['当前HJB收敛率=',num2str(convergent_total),'/31. NKratiogap最大省份：',results{maxKNprv}.prvname,', KNratiogap= ',num2str(maxKNratiogap), '. Ytgap最大省份：',results{maxYgapprv}.prvname,', Ygap= ',num2str(maxYtgap)]))
	disp(strcat(['当前HJB收敛率=',num2str(convergent_total),'/31。 maxKNgap= ',num2str(maxKNratiogap),', maxYgap= ',num2str(maxYtgap), '————————ra最大和最小省份个数为：', num2str(maxra),'--' num2str(minra),'。 wjt最大和最小省份个数为：', num2str(maxwjt),'--' num2str(minwjt) ]))
	%disp(strcat(['————————ra最大和最小省份个数为：', num2str(maxra),'--' num2str(minra), '，ra最大省份分别为: ',strjoin(maxraprvs, ' '), '，ra最小省份分别为：',strjoin(minraprvs, ' '), '。 wjt最大和最小省份个数为：', num2str(maxwjt),'--' num2str(minwjt), '。wjt最大省份分别为: ',strjoin(maxwjtprvs, ' '), '，wjt最小省份分别为：',strjoin(minwjtprvs, ' ')]))
	%disp(strcat(['————————ra最大和最小省份个数为：', num2str(maxra),'--' num2str(minra), '，ra最大省份分别为: ',strjoin(maxraprvs, ' '), '，ra最小省份分别为：',strjoin(minraprvs, ' '), '。 wjt最大和最小省份个数为：', num2str(maxwjt),'--' num2str(minwjt), '。wjt最大省份分别为: ',strjoin(maxwjtprvs, ' '), '，wjt最小省份分别为：',strjoin(minwjtprvs, ' ')]))

	if maxKNratiogap<reg_threshold && maxYtgap<reg_threshold && convergent_total==31 && maxra==0 && minra==0
		disp(['多省份HANK模型局部收敛, Iteration = ',num2str(j)])
		finish = 1;
		break
	else
		if maxKNratiogap< 0.1 && steady_state == 1 % 求解稳态时允许调整grid参数
			for i = 1:N_prov
				if results{i}.Yt / results{i}.Yt0 - 1 > 0.01 || results{i}.Yt / results{i}.Yt0 - 1 < -0.01
					results{i}.Zt = results{i}.Yt0 * results{i}.Kt^(-results{i}.alpha) * results{i}.Lt^(results{i}.alpha-1);
				end
				if results{i}.ra < grids{i}.ramin+0.02
					results{i}.GovInv = results{i}.GovInv*(1 - 0.1);
				elseif results{i}.ra > grids{i}.ramax-0.02
					results{i}.GovInv = results{i}.GovInv*(1 + 0.1);
				end
				test = 'pass';
			end
		end
		for i = 1:N_prov
			tKNratio(i) = 0.6*results{i}.KNratio+0.4*tKNratio(i);
		end
	end
	if j == num.max3iter
		error("稳态没能成功收敛！")
	end
end
