function eq = HANK3_cost(results,paramchi,d,a,foreign)
chi0 = paramchi.chi0;
chi1 = paramchi.chi1;
fixcost = paramchi.fixcost;
%fixcost = 0;
fixcost2 = paramchi.fixcost2;
%fixcost2 = 0;
a_bar = paramchi.a_bar;
PFt = 1;
Pt = 1;
et = 1;
price = PFt*et/Pt;
%price = 1;
%eq = foreign*fixcost + chi0.*abs(d) + chi1.*d.^2/2.*(max(a,10^(-6))).^(-1);
if foreign == 1 % 外国资产情况：需要计算价格
	%eq = fixcost + chi0.*abs(d./price) + chi1.*(d./price).^2/2.*(max(a,a_bar)).^(-1);
	chi0 = chi0 + fixcost2;
	%chi1 = chi1 + fixcost2;
	eq = fixcost + chi0.*abs(d./price) + chi1.*(d./price).^2/2.*(max(a,a_bar)).^(-1);

else
	eq = chi0.*abs(d) + chi1.*d.^2/2.*(max(a,a_bar)).^(-1);
end

end
