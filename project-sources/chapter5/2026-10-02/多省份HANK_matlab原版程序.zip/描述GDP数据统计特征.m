% 指定Excel文件路径
readfile = "2000年后各省数据.xlsx";

% 获取Excel文件的工作表名称
[~, sheets] = xlsfinfo(readfile);
datamat = zeros(length(sheets),6);
% 循环读取每个工作表的内容，并储存统计内容
for i = 1:length(sheets)
	sheetName = sheets{i};
	tempdata = xlsread(readfile, sheetName, "C2:AG25");
	datamat(i,2) = numel(find(isnan(tempdata)));
	datamat(i,1) = numel(tempdata) - datamat(i,2);
	datamat(i,3) = mean(tempdata, 'all','omitnan');
	datamat(i,4) = std(tempdata, 1, 'all','omitnan');
	datamat(i,5) = min(tempdata, [], 'all','omitnan');
	datamat(i,6) = max(tempdata, [], 'all','omitnan');
end


colnames = {'Obs', 'NaNs', 'Mean', 'Std.dev.', 'Min', 'Max'}; % 示例列名称  
  
% 打开一个文件以写入  
fileID = fopen('描述中国省级数据.tex', 'w');  
  
% 写入 LaTeX 表格的开头  
fprintf(fileID, '\\begin{table}\n');  
fprintf(fileID, '\\centering\n');  
fprintf(fileID, '\\begin{tabular}{lcccccc}\n');  
fprintf(fileID, '\\hline\n');  
fprintf(fileID, 'Variable ');  
  
% 写入列名称  
for j = 1:length(colnames)
	fprintf(fileID, strcat(" & ",colnames{j})); % 将列名称转换为字符串并写入  
end
fprintf(fileID, ' \\\\ \n');  
fprintf(fileID, '\\hline\n');  
  
% 写入矩阵数据和行名称  
for i = 1:size(datamat, 1)  
    fprintf(fileID, sheets{i}); % 写入行名称  
    for j = 1:size(datamat, 2)  
		fprintf(fileID, ' &');
        fprintf(fileID, '%.2f ', datamat(i, j)); % 写入矩阵数据，保留2位小数  
    end  
    fprintf(fileID, ' \\\\ \n');  
end  
  
% 写入 LaTeX 表格的结尾  
fprintf(fileID, '\\hline\n');  
fprintf(fileID, '\\end{tabular}\n');  
fprintf(fileID, '\\caption{Your table caption here.}\n'); % 添加表格标题  
fprintf(fileID, '\\label{your_table_label}\n'); % 添加表格标签  
fprintf(fileID, '\\end{table}\n');  
  
% 关闭文件  
fclose(fileID);