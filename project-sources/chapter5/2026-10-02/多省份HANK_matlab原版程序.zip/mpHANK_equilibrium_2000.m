function st = mpHANK_equilibrium_2000(param,grids,num,CHI,inits,data_MAT, st_ind, data_year);
	% 2023年12月6日 多省份HANK模型的稳态求解
	% 算法说明：每个省份计算各自的消费、储蓄和产出，然后对照现实数据去调整跨省份的劳动系数矩阵。
	% 初版算法，假设所有省份的基础参数都相同。这个假设问题很大，但是暂时不调整了。
	%% 2024年4月18日：修改为单一参数拟合的算法。
	% 5月3日：修改了程序输入，现在只计算各省的总GDP相关稳态，这个版本每各省只估计一个Zt和一个alpha，同时Yt、Kt、Lt数据使用2010年的。
	global N_prov;
	real_GDP_vec = zeros(N_prov,1); % 存放现实中本年度的GDP数据
	results_pgdp = zeros(N_prov,1); % 存放现实中本年度的人均GDP数据
	results_pcap = zeros(N_prov,1); % 存放现实中本年度的人均资本数据
	results = inits;
%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 读取数据
%%%%%%%%%%%%%%%%%%%%%%%%%%
	disp(' ');
	disp('开始读取数据');
	sigmau_MAT = load_distdata(param.max_sigmau); % 最大迁移成本设定为 param.max_sigmau
	
%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 初始化参数设置
%%%%%%%%%%%%%%%%%%%%%%%%%%
	for i = 1:N_prov
		% 这个程序只计算第st_ind产业的第1年的稳态
		%results{i}.Zt = data_MAT.IND_Zt{st_ind}(1,i); % 估计的该省产业生产力
		results{i}.Zt = data_MAT.IND_Zt{st_ind}(1,i) * param.Ztratio;
		results{i}.alpha = data_MAT.IND_alpha{st_ind}(1,i); % 估计的该省产业资本弹性
		results{i}.Kt0 = data_MAT.CAP{st_ind}(data_year,i); % 实际产业总资本数据
		results{i}.Kt = results{i}.Kt0;
		results{i}.N = data_MAT.POP{st_ind}(data_year,i); % 实际产业人口规模数据
		results{i}.Lt = results{i}.N;
		results{i}.Yt0 = data_MAT.GDP{st_ind}(data_year,i); % 实际产业GDP数据
		results{i}.Yt = results{i}.Yt0;
		results{i}.Zt_1 = results{i}.Zt;
		results{i}.Kt_1 = results{i}.Kt;
		results{i}.Lt_1 = results{i}.Lt;
		results{i}.mt = 1/results{i}.Zt * (results{i}.rk/results{i}.alpha)^results{i}.alpha * (results{i}.wjt/(1-results{i}.alpha))^(1-results{i}.alpha);
		results{i}.pcap = exp(data_MAT.log_pcap{st_ind}(data_year,i)); % 实际产业人均资本数据
		results{i}.pgdp = exp(data_MAT.log_pgdp{st_ind}(data_year,i)); % 实际产业人均GDP数据
		results{i}.prvname = data_MAT.prvname{i};
		results{i}.GovInv = results{i}.Kt0*param.GovInv_ratio;
		real_GDP_vec(i) = data_MAT.GDP{st_ind}(data_year,i); % 实际GDP
		results_pgdp(i) = exp(data_MAT.log_pgdp{st_ind}(data_year,i)); % 实际人均GDP
		results_pcap(i) = exp(data_MAT.log_pcap{st_ind}(data_year,i)); % 实际人均固定资产
	end
	
	% 根据人均cap设置每个省份购买外省资产的比例，最低0%，最高30%
	maxpcap = max(results_pcap);
	minpcap = min(results_pcap);
	for i = 1:N_prov
		results{i}.inter_prv_ratio = 0.0 + 0.3*(results_pcap(i)-minpcap)/(maxpcap-minpcap);
	end

%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 开始循环
%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
for laps = 1:1
	% 开始迭代
		disp(' ');
		disp(' ');
		disp(['开始第', num2str(laps),'轮迭代']);
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%
	%% 预先计算家户产出Yt向量
	%%%%%%%%%%%%%%%%%%%%%%%%%%
		disp(' ');
		disp('开始计算本轮迭代的稳态');
		% 计算每个省份的家户部门，粗略算出当前轮次的稳态总产出
		tic
		show_result = 1; % 是否输出各省的调试信息
		% 计算稳态，通过不断调整grid.amax和GovInv来修正稳态值。
		[final_res, GDP_vec, finish] = HANK_mp_1eq(results, param, grids, num, CHI, sigmau_MAT, N_prov, num.reg_threshold, show_result, 1);
		toc
		disp(' 本轮迭代生成的Ytvec:');
		disp(GDP_vec')
		disp(' 目标Ytvec:');
		disp(real_GDP_vec')

end
% 添加稳态变量值，为冲激响应做准备。
for i = 1:N_prov
	final_res{i}.Zt_ss = final_res{i}.Zt;
	final_res{i}.Kt_ss = final_res{i}.Kt;
	final_res{i}.Lt_ss = final_res{i}.Lt;
	final_res{i}.pit_ss = final_res{i}.pit;
end
st.results = final_res;
st.grids = grids;
st.sigmau_MAT = sigmau_MAT;
st.N_prov = N_prov;
st.data_MAT = data_MAT;
st.grids = grids;
st.param = param;
st.num = num;
st.CHI = CHI; 














