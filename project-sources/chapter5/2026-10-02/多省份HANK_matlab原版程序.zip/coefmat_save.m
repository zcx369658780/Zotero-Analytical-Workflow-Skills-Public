function T1 = coefmat_save(coef_total_mat, IRF_vars,prov_names, year_names, prefixname, savefile)
% 保存各省份外溢性系数矩阵


	%% 包含多个变量的冲击结果，每个都是31*12
	for k = 1:1
		for ivar = 1:length(IRF_vars)
			sheetname1 = strcat(prefixname,"_",IRF_vars{ivar});
			%% 第一种方法：每一列存放一年的数据
			%T1 = array2table(coef_total_mat{ivar}, 'VariableNames', year_names);   % 存放系数的矩阵
			%prov_names_col = cell2table(prov_names', 'VariableNames', {'省份'});
			
			%% 下面是转置后的，每一列存放一个省的数据
			T1 = array2table(coef_total_mat{ivar}, 'VariableNames', prov_names);   % 存放系数的矩阵
			prov_names_col = cell2table(year_names', 'VariableNames', {'时间'});  
			T1 = [prov_names_col, T1];  
			% 使用 writetable 函数写入 Excel 文件  
			if exist(savefile)==0 % 如果不存在保存文件，就创建，否则添加到后面。
				writetable(T1, savefile, 'Sheet', sheetname1);  
			else
				writetable(T1, savefile, 'Sheet', sheetname1, 'WriteMode', 'append');   
			end  
			
		end
	end




