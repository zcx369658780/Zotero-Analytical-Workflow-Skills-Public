function Kt = It_to_Kt(Invest_vec, delta)
%% 根据投资额序列估计资本存量序列。
%% Invest_vec是一个21行 33列的矩阵
Msize = size(Invest_vec);
Kt = zeros(Msize(1),Msize(2));
Kt(1,:) = Invest_vec(1,:)/0.1; % 初始Kt设定为It的10倍
for j = 1:Msize(2)
	for i = 2:Msize(1)
		Kt(i,j) = (1-delta)*Kt(i-1,j) + Invest_vec(i-1,j);
	end
end