function IRF = mpHANK_shock_2000(st, shocks,T);
	% 2023年12月6日 多省份HANK模型的稳态求解
	% 算法说明：每个省份计算各自的消费、储蓄和产出，然后对照现实数据去调整跨省份的劳动系数矩阵。
	% 初版算法，假设所有省份的基础参数都相同。这个假设问题很大，但是暂时不调整了。
	%% 2024年4月18日：修改为单一参数拟合的算法。
	% 5月3日：修改了程序输入，现在只计算各省的总GDP相关稳态，这个版本每各省只估计一个Zt和一个alpha，同时Yt、Kt、Lt数据使用2010年的。
%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 读取数据
%%%%%%%%%%%%%%%%%%%%%%%%%%
	global N_prov;
	tic
	% 只读取一次稳态结果，后续的结果都是用这个初始值迭代下去。
	results = st.results;
	grids = st.grids;
	param = st.param;
	num = st.num;
	CHI = st.CHI; 


%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 初始化参数设置
%%%%%%%%%%%%%%%%%%%%%%%%%%
%for i=1:N_prov
	%grids{i}.ramax = 0.12;
%end

%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 开始循环
%%%%%%%%%%%%%%%%%%%%%%%%%%
for iter = 1:T
	%sigmau_MAT = st.sigmau_MAT;
	sigmau_MAT = load_distdata(param.max_sigmau*(1+shocks.epsilon_sigmau(iter)));

	% 引入shock变量
	for i = 1:N_prov
		results{i}.Zt = st.results{i}.Zt * (1 + shocks.epsilon_z{i}(iter));
		results{i}.GovInv = st.results{i}.GovInv * (1 + shocks.epsilon_gv{i}(iter));
		results{i}.tau = st.results{i}.tau * (1 + shocks.epsilon_tauw{i}(iter));
		results{i}.corptau = st.results{i}.corptau * (1 + shocks.epsilon_tauf{i}(iter));
		results{i}.epsilon_pi = shocks.epsilon_pi{i}(iter);
	end
	
	show_result = 0; % 是否输出各省的调试信息
	
	%% 开始计算冲激响应。注意不能用1eq那个程序
	[results, GDP_vec] = HANK_mp_1turn(results, param, grids, num, CHI, sigmau_MAT, N_prov, show_result, 1);
	maxra=0;minra=0;maxraprvs = {}; minraprvs= {};
	for i = 1:N_prov
		if results{i}.ra == grids{i}.ramax
			maxra = maxra+1;maxraprvs{end+1} = results{i}.prvname;
		elseif results{i}.ra == grids{i}.ramin
			minra = minra+1;minraprvs{end+1} = results{i}.prvname;
		end
	end
	for i = 1:N_prov
		if isreal(results{i}.Yt) == 0
			error('————Programme Break!')
		end

	end
	if show_result==1
		disp(['ra最大和最小省份个数为：', num2str(maxra),'--' num2str(minra), '。ra最大省份分别为: ',strjoin(maxraprvs, ' '), '，ra最小省份分别为：',strjoin(minraprvs, ' ')])
	end
	
	%%  保存计算结果
	IRF{iter} = results;
end
toc

