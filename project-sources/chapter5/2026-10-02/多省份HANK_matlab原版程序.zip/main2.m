%%% 2023年12月6日 多省份神经网络HANK模型主程序
%%% 这个程序调用其他程序并且完成画图。
%%% 2024年9月23日：修改为增长极的衡量

clear all; close all; clc;
global Ncores; Ncores = 2;
global myfontsize; myfontsize = 14;
global N_prov; N_prov = 31;
%NIRFs = N_prov;
maxyear = 15; % 2009-2023年
NIRFs = 31;
T = 20;
[all_themes, all_colors] = GetColors(); % 使用自定义色表
for j = 1:NIRFs
	shock{j}.T = T;
	shock{j}.NIRFs = NIRFs;
	shock{j}.epsilon_sigmau = zeros(T,1);
	for i = 1:N_prov
		shock{j}.epsilon_z{i} = zeros(T,1);
		shock{j}.epsilon_gv{i} = zeros(T,1);
		shock{j}.epsilon_tauw{i} = zeros(T,1);
		shock{j}.epsilon_tauf{i} = zeros(T,1);
		shock{j}.epsilon_pi{i} = zeros(T,1);
	end
end
shocks{1} = shock;shocks{2} = shock; shocks{3} = shock;shocks{4} = shock;

% 所有省份都要跑全部的冲击，用来衡量不同政策对发展极的度量程度。
show_prv = 1:31;
shocks{1}{1}.NIRFs = length(show_prv);% 前三个冲击只跑5个省份，节省时间。
shocks{2}{1}.NIRFs = length(show_prv);
shocks{3}{1}.NIRFs = length(show_prv);
shocks{4}{1}.NIRFs = length(show_prv);% 货币政策是全国性的。


% 综合政策模拟有5个冲击，分别是：减税，降低利率，供给侧改革提高生产力，区域融合发展降低迁移成本，以及这四个冲击合起来。政策模拟只跑4期（一年，每一期一个季度）


shocknames_policy = {};
for k= 1:maxyear
	shocknames_policy{k} = strcat('综合政策冲击_',num2str(k+2008));
end

	Tvec = 1:T; shockrange = 0.01; shockvar = 0.5;
	shockseries =(shockrange)* exp(-(1-shockvar)*(Tvec-1));

%shocknames = {'生产力冲击';'国有资产冲击';'企业税率冲击';'扩张货币政策'};
shocknames = {'生产力冲击'};

% 演示的冲击变量与省份
IRF_vars = {"Yt","Ct","Lt","Kt","gini_income","gini_aht"};
	for i = 1:length(show_prv) % 4类冲击，都是单个省份的
		shocks{1}{i}.epsilon_z{show_prv(i)} = shockseries; % 前31个冲击是生产力冲击
		shocks{2}{i}.epsilon_gv{show_prv(i)} = shockseries; % 后31个冲击是政府投资的冲击
		shocks{3}{i}.epsilon_tauf{show_prv(i)} = -shockseries; % 然后是企业税率冲击
		shocks{4}{i}.epsilon_pi{show_prv(i)} = -shockseries*0.1; % 扩张性货币政策
	end

%% IRF{3}{ishow_prv}里面存放的是第三种、工资税率冲击中，第二个展示省份，也即实际上第九个省发生冲击的全部变量

% 定义五种颜色的RGB值，和R语言那边的颜色风格保持一致。
	custom_colors = [  
    0.0000 0.2412 0.4510; % #003973  
    0.0000 0.4235 0.1725; % #006d2c  
    1.0000 0.4980 0.0000; % #ff7f00  
    0.4118 0.0000 0.6588; % #6a00a8  
    0.6980 0.1098 0.1843; % #b2182b  
];  

%% 2009-2023，连续15年的稳态图
runsts = 1;
if runsts == 1
	if isempty(gcp('nocreate'))
		parpool(Ncores);
	end
	parfor i = 1:maxyear
	%for i = 1:maxyear
		%sts{i} = multi_prov_HANK_12sts(i,1);
		sts{i} = multi_prov_HANK_12sts(i,0);
	end

	%error('st test!')

	for i = 1:N_prov
		Ytvec{i} = zeros(maxyear, 1);
		Ktvec{i} = zeros(maxyear, 1);
		Ltvec{i} = zeros(maxyear, 1);
		Ctvec{i} = zeros(maxyear, 1);
		ravec{i} = zeros(maxyear, 1);
	end

	for i = 1:N_prov
		for iyear = 1:maxyear
			Ytvec{i}(iyear) = sts{iyear}.results{i}.Yt/sts{1}.results{i}.Yt-1;
			Ctvec{i}(iyear) = sts{iyear}.results{i}.Ct_total/sts{1}.results{i}.Ct_total-1;
			Ltvec{i}(iyear) = sts{iyear}.results{i}.Lt/sts{1}.results{i}.Lt-1;
			Ktvec{i}(iyear) = sts{iyear}.results{i}.Kt/sts{1}.results{i}.Kt-1;
			ravec{i}(iyear) = sts{iyear}.results{i}.ra/sts{1}.results{i}.ra-1;
		end
	end

	close all;
	h = figure(1);
	Tvec12 = 2009:2023;
	set(h, 'name', '12prov sts');
		set(gcf,'color','white'); 
		set(gca, 'FontName','arial','FontSize', myfontsize, 'FontWeight', 'bold', 'ColorOrder', custom_colors); hold all;
		tiledlayout('flow','TileSpacing','compact','Padding','compact');

	for i = 1:N_prov
		nexttile
		plot(Tvec12, Ytvec{i}, Tvec12, Ctvec{i}, Tvec12, Ltvec{i}, Tvec12, Ktvec{i}, Tvec12, ravec{i}, 'LineWidth', 2); 
		set(gca, 'ColorOrder', custom_colors);
		grid on;grid minor;title(sts{1}.results{i}.prvname,'FontSize', myfontsize)
	end
	
	nexttile
	plot(Tvec12,zeros(maxyear, 1), Tvec12,zeros(maxyear, 1), Tvec12,zeros(maxyear, 1), Tvec12,zeros(maxyear, 1), Tvec12, zeros(maxyear, 1), 'LineWidth', 2); 
	set(gca, 'ColorOrder', custom_colors);
	legend("产出Yt","消费Ct","劳动供给Lst","资本供给Kst", "资产回报率ra", 'FontSize', myfontsize-4)
	grid on;grid minor;title('2009-2020年稳态值增长率','FontSize', myfontsize)

		warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
		jFrame = get(h,'JavaFrame');
		pause(0.7);
		set(jFrame,'Maximized',1);
		pause(0.7);
		warning('on','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');

		exportgraphics(h,'2009-2020年稳态值变化图.png','Resolution',96); 
	close all;
	else
	for i = 1:maxyear
		sts{i} = multi_prov_HANK_12sts(i,0);
	end

	%error("sts test")

	%% 将稳态的劳动力迁移矩阵保存到excel中
	%% 注意，Ltmat固定保存在第31个省份的results中
	for i = 1:N_prov
		prov_names{i} = sts{1}.results{i}.prvname;
	end
	if exist("12年稳态Ltmat.xlsx") == 2
		delete("12年稳态Ltmat.xlsx")
	end
	for iyear = 1:maxyear
		Ltmat_save(prov_names, sts{iyear}.results{31}.Lt_mat, "12年稳态Ltmat.xlsx", strcat(num2str(iyear+2008),'年'));
	end
	%% 保存各省每年的稳态值和实际值
	Yt_file = "12年稳态值.xlsx";
	if exist(Yt_file) ~= 2
		delete(Yt_file);
	end
	for i = 1:N_prov
		prov_names{i} = sts{12}.results{i}.prvname;
	end
	for jj = 1:6
		MyMat{jj} = zeros(31,12);
	end
	for iyear = 1:maxyear
		yearnum{iyear} = num2str(iyear+2008);
		for iprv = 1:N_prov
			MyMat{1}(iprv,iyear) = sts{iyear}.results{iprv}.Yt0 / sts{iyear}.param.GDP_multiplier;
			MyMat{2}(iprv,iyear) = sts{iyear}.results{iprv}.Yt / sts{iyear}.param.GDP_multiplier;
			MyMat{3}(iprv,iyear) = sts{iyear}.results{iprv}.Kt0 / sts{iyear}.param.GDP_multiplier;
			MyMat{4}(iprv,iyear) = sts{iyear}.results{iprv}.Kt / sts{iyear}.param.GDP_multiplier;
			MyMat{5}(iprv,iyear) = sts{iyear}.results{iprv}.N / sts{iyear}.param.POP_multiplier;
			MyMat{6}(iprv,iyear) = sts{iyear}.results{iprv}.Lt / sts{iyear}.param.POP_multiplier;
		end
	end
	Matnames = {"Yt0","Yt","Kt0","Kt","Lt0","Lt"};
	for jj = 1:6
		sheetname1 = strcat("稳态值_",Matnames{jj});
		T1 = array2table(MyMat{jj}, 'VariableNames', yearnum);
		prov_names_col = cell2table(prov_names', 'VariableNames', {'省份'});
		T1 = [prov_names_col, T1];
		writetable(T1, Yt_file, 'Sheet', sheetname1, 'WriteMode', 'append');
	end
end

%error("稳态结果12年稳态值保存完毕")

%% 读取稳态和IRF结果。内存不够大不建议这么读取。
load_irf = 1;
	if load_irf == 1
		if isempty(gcp('nocreate'))
			parpool(Ncores);
		end
		%parfor k = 1:4
		parfor iyear = 1:maxyear
			%[IRF{iyear}, st2{iyear}] = multi_prov_HANK(shocks{1}, shocknames{1}, iyear+2008, 0); % 修改为只跑技术冲击。
			multi_prov_HANK(shocks{1}, shocknames{1}, iyear+2008, 0); % 修改为只跑技术冲击。
		end
	end

%error('读取2012年IRF')

%% IRF影响的弹性，也即某个省份冲击变量1个百分点引起其他省份变化的百分比。
%% 分为加总百分比，和最高百分比两种影响。都算。
%% 需要注意，矩阵的第j行是冲击发生在第j个省份后，对所有省份的影响。也即，扣除(j,j)位置后这一行的变量都是第j个省份冲击对其他省份的影响。


for j = 1:5
	for ivar = 1:length(IRF_vars)
		coef_total_mat{j}{ivar} = zeros(15,N_prov); % 存放系数的矩阵
	end
end
% 更换变量表
IRF_vars = {"Yt","Lt","Kt","Zt","Ct","pgdp","pcap","w","rah"};
for ivar = 1:length(IRF_vars) % 受到影响的5种变量
	vars = IRF_vars{ivar};
	for iyear = 1:maxyear % 12年全部测算
		[IRF, st2] = multi_prov_HANK(shocks{1}, shocknames{1}, iyear+2008, 0); % 修改为只跑技术冲击。

		tempvec1 = zeros(31,1);
		tempvec2 = zeros(31,1);
		tempvec3 = zeros(31,1);
		tempvec4 = zeros(31,1);
		tempvec5 = zeros(31,1);
		for shockprov = 1:N_prov % 衡量全部省份的冲击影响
			var_vec = zeros(T,1);
			for i = 1:N_prov % 对31个省的影响
				if vars =="Income" % 这个是没加总的3维矩阵，需要特殊处理。
					var_st = sum(st2.results{i}.Income .* st2.results{i}.g, 'all');
					for time = 1:T
					var_vec(time) = sum(IRF{shockprov}{time}{i}.Income .* st2.results{i}.g, 'all');
					end
				else
					var_st = eval(strcat("st2.results{i}.",vars)); 
					for time = 1:T
						var_vec(time) = eval(strcat("IRF{shockprov}{time}{i}.",vars));
					end
				end
				tempvec1(i) = sum(var_vec - var_st); % 绝对差值
				tempvec2(i) = sum(var_vec/var_st - 1); % 百分比差值
				tempvec3(i) = var_st; % 稳态值
				tempvec4(i) = max_abs_value(var_vec - var_st); % 最大或最小
				tempvec5(i) = max_abs_value(var_vec/var_st - 1); % 最大或最小
			end
		coef_total_mat{1}{ivar}(iyear,shockprov) = (sum(tempvec1) - tempvec1(shockprov)/tempvec1(shockprov));
		coef_total_mat{2}{ivar}(iyear,shockprov) = (sum(tempvec2) - tempvec2(shockprov)/tempvec2(shockprov));
		coef_total_mat{3}{ivar}(iyear,shockprov) = tempvec3(shockprov);
		coef_total_mat{4}{ivar}(iyear,shockprov) = (sum(tempvec4) - tempvec4(shockprov))/tempvec4(shockprov);
		coef_total_mat{5}{ivar}(iyear,shockprov) = (sum(tempvec5) - tempvec5(shockprov)/tempvec5(shockprov));
		%coef_total_mat{6}{ivar}(iyear,shockprov) = sum(tempvec1);
		%coef_total_mat{7}{ivar}(iyear,shockprov) = sum(tempvec2);

		
		end
	end
end

	for i = 1:N_prov
		prov_names{i} = sts{1}.results{i}.prvname;
	end
	for i = 1:maxyear
		year_names{i} = strcat(num2str(i+2008),'年');
	end

excelfile = "31x12外溢系数影响矩阵.xlsx";
	if exist(excelfile)
		delete(excelfile);
	end
%prefix = {"delta","dot","ss","maxdelta","maxdot","alldelta","alldot"};
prefix = {"delta","dot","ss","maxdelta","maxdot"};
for j = 1:length(coef_total_mat)
	coefmat_save(coef_total_mat{j}, IRF_vars,prov_names, year_names, prefix{j}, excelfile);
end





















