function mydata2 = load_GDPdata(GDP_multiplier, POP_multiplier, delta, smooth_method, reg_method)
%% 读取GDP等实际数据。注意第一列是年份，第二列是全国总值。
%% 旧数据说明：GDP(亿元) 常住人口(万人) 总人口数(万人) 固定资产投资额(万元)
tic
writefile = "2000年后各省数据_填充NA.xlsx";

if exist(writefile) ~= 2 % 不存在处理后的数据文件，先平滑处理。
	% 读取原始数据
	readfile = "2000年后各省数据.xlsx";
	[temp1,header] = xlsread(readfile, "GDP");temp1 = fillmissing(temp1, 'makima'); mydata.prvname = header(1,3:33);
	temp2 = readmatrix(readfile, 'Sheet', "固定资产投资额", 'Range', 'B2:AG25');temp2 = fillmissing(temp2, 'makima');
	temp31 = readmatrix(readfile, 'Sheet', "总人口数", 'Range', 'B2:AG25');temp31 = fillmissing(temp31, 'makima');
	temp32 = readmatrix(readfile, 'Sheet', "常住人口", 'Range', 'B2:AG25');temp32 = fillmissing(temp32, 'makima');
	temp33 = readmatrix(readfile, 'Sheet', '就业人数', 'Range', 'B2:AG25');temp33 = fillmissing(temp33, 'makima');
	temp4 = readmatrix(readfile, 'Sheet', "第一产业固定资产投资额", 'Range', 'B2:AG25');temp4 = fillmissing(temp4, 'makima');% 
	temp5 = readmatrix(readfile, 'Sheet', "第一产业从业人员数", 'Range', 'B2:AG25');temp5 = fillmissing(temp5, 'makima');
	temp6 = readmatrix(readfile, 'Sheet', "第一产业占GDP的比重", 'Range', 'B2:AG25');temp6 = fillmissing(temp6, 'makima');
	temp7 = readmatrix(readfile, 'Sheet', "第二产业固定资产投资额", 'Range', 'B2:AG25');temp7 = fillmissing(temp7, 'makima');% 
	temp8 = readmatrix(readfile, 'Sheet', "第二产业从业人员数", 'Range', 'B2:AG25');temp8 = fillmissing(temp8, 'makima');
	temp9 = readmatrix(readfile, 'Sheet', "第二产业占GDP比重", 'Range', 'B2:AG25');temp9 = fillmissing(temp9, 'makima');
	temp10 = readmatrix(readfile, 'Sheet', "第三产业固定资产投资额", 'Range', 'B2:AG25');temp10 = fillmissing(temp10, 'makima');% 
	temp11 = readmatrix(readfile, 'Sheet', "第三产业从业人员数", 'Range', 'B2:AG25');temp11 = fillmissing(temp11, 'makima');
	temp12 = readmatrix(readfile, 'Sheet', "第三产业占GDP的比重", 'Range', 'B2:AG25');temp12 = fillmissing(temp12, 'makima');

	% 将平滑处理后的数据储存下来
	xlswrite(writefile, header, "GDP", "A1:AG25");
	xlswrite(writefile, temp1, "GDP", "B2:AG25");
	xlswrite(writefile, header, "固定资产投资额", "A1:AG25");
	xlswrite(writefile, temp2, "固定资产投资额", "B2:AG25");
	xlswrite(writefile, header, "总人口数", "A1:AG25");
	xlswrite(writefile, temp31, "总人口数", "B2:AG25");
	xlswrite(writefile, header, "常住人口", "A1:AG25");
	xlswrite(writefile, temp32, "常住人口", "B2:AG25");
	xlswrite(writefile, header, "就业人数", "A1:AG25");
	xlswrite(writefile, temp33, "就业人数", "B2:AG25");
	xlswrite(writefile, header, "第一产业固定资产投资额", "A1:AG25");
	xlswrite(writefile, temp4, "第一产业固定资产投资额", "B2:AG25");
	xlswrite(writefile, header, "第一产业从业人员数", "A1:AG25");
	xlswrite(writefile, temp5, "第一产业从业人员数", "B2:AG25");
	xlswrite(writefile, header, "第一产业占GDP的比重", "A1:AG25");
	xlswrite(writefile, temp6, "第一产业占GDP的比重", "B2:AG25");
	xlswrite(writefile, header, "第二产业固定资产投资额", "A1:AG25");
	xlswrite(writefile, temp7, "第二产业固定资产投资额", "B2:AG25");
	xlswrite(writefile, header, "第二产业从业人员数", "A1:AG25");
	xlswrite(writefile, temp8, "第二产业从业人员数", "B2:AG25");
	xlswrite(writefile, header, "第二产业占GDP比重", "A1:AG25");
	xlswrite(writefile, temp9, "第二产业占GDP比重", "B2:AG25");
	xlswrite(writefile, header, "第三产业固定资产投资额", "A1:AG25");
	xlswrite(writefile, temp10, "第三产业固定资产投资额", "B2:AG25");
	xlswrite(writefile, header, "第三产业从业人员数", "A1:AG25");
	xlswrite(writefile, temp11, "第三产业从业人员数", "B2:AG25");
	xlswrite(writefile, header, "第三产业占GDP的比重", "A1:AG25");
	xlswrite(writefile, temp12, "第三产业占GDP的比重", "B2:AG25");
	
	% 估算出新资本存量数据
	tempK0 = It_to_Kt(temp2, delta);
	tempK1 = It_to_Kt(temp4, delta);
	tempK2 = It_to_Kt(temp7, delta);
	tempK3 = It_to_Kt(temp10, delta);
	xlswrite(writefile, header, "总资本存量", "A1:AG25");
	xlswrite(writefile, tempK0, "总资本存量", "B2:AG25");
	xlswrite(writefile, header, "第一产业资本存量", "A1:AG25");
	xlswrite(writefile, tempK1, "第一产业资本存量", "B2:AG25");
	xlswrite(writefile, header, "第二产业资本存量", "A1:AG25");
	xlswrite(writefile, tempK2, "第二产业资本存量", "B2:AG25");
	xlswrite(writefile, header, "第三产业资本存量", "A1:AG25");
	xlswrite(writefile, tempK3, "第三产业资本存量", "B2:AG25");
	
end




	[temp1,header] = xlsread(writefile, "GDP"); mydata.prvname = header(1,3:33);
	temp2 = xlsread(writefile, "总资本存量");
	%temp2 = xlsread(writefile, "R语言计算资本存量"); temp2 = fillmissing(temp2, 'makima');% 先运行E:\R\main.r，这个sheet的数据是R语言中的包计算得到的。
	%temp2 = readmatrix(writefile, 'Sheet', "R语言计算资本存量", 'Range', 'B2:AG25');temp2 = fillmissing(temp2, 'makima');% 先运行E:\R\main.r，这个sheet的数据是R语言中的包计算得到的。

	temp3 = xlsread(writefile, "常住人口");
	%temp3 = xlsread(writefile, "就业人数");
	%temp3 = xlsread(writefile, "总人口数");
	temp4 = xlsread(writefile, "第一产业资本存量");temp4 = fillmissing(temp4, 'makima');
	temp5 = xlsread(writefile, "第一产业从业人员数");
	temp6 = xlsread(writefile, "第一产业占GDP的比重");
	temp7 = xlsread(writefile, "第二产业资本存量");temp7 = fillmissing(temp7, 'makima');
	temp8 = xlsread(writefile, "第二产业从业人员数");
	temp9 = xlsread(writefile, "第二产业占GDP比重");
	temp10 = xlsread(writefile, "第三产业资本存量");temp10 = fillmissing(temp10, 'makima');
	temp11 = xlsread(writefile, "第三产业从业人员数");
	temp12 = xlsread(writefile, "第三产业占GDP的比重");

	% 按照不同产业分类去估计GDP
	mydata.GDP{4} = temp1(:,2:32)*GDP_multiplier; 
	mydata.CAP{4} = temp2(:,2:32)*GDP_multiplier; 
	mydata.GDP{1} = temp1(:,2:32) .* temp6(:,2:32) / 100; 
	mydata.CAP{1} = temp4(:,2:32)*GDP_multiplier; 
	mydata.GDP{2} = temp1(:,2:32) .* temp9(:,2:32) / 100; 
	mydata.CAP{2} = temp7(:,2:32)*GDP_multiplier; 
	mydata.GDP{3} = temp1(:,2:32) .* temp12(:,2:32) / 100; 
	mydata.CAP{3} = temp10(:,2:32)*GDP_multiplier; 
	mydata.POP{1} = temp5(:,2:32)*POP_multiplier; 
	mydata.POP{2} = temp8(:,2:32)*POP_multiplier; 
	mydata.POP{3} = temp11(:,2:32)*POP_multiplier; 
	mydata.POP{4} = temp3(:,2:32)*POP_multiplier; 

reg_file = strcat("数据估计结果_",num2str(GDP_multiplier),"_",num2str(POP_multiplier),"_",num2str(reg_method),".mat");
if exist(reg_file) == 2 % 存在估计结果的时候，直接读取。
	disp(['发现数据文件: ', reg_file,', 读取估计数据...'])
	temp2 = struct2cell(load(reg_file,'mydata2'));
	mydata2 = temp2{1};
else
	for ii = 1:15
	if reg_method == 0 % 读取R语言的回归结果，并且反向求出Zt
		% Zt = exp( alpha*log(Kt/Lt) - log(Yt/Lt) )
		regfile = "R语言估计结果_plm估计.xlsx";
		for j = 1:4
			sheet_name1 = strcat("总面板回归系数_",num2str(ii+9),"_行业", num2str(j));
			reg_temp1 = xlsread(regfile, sheet_name1);
			reg_alpha{j} = reg_temp1(length(reg_temp1)); % alpha的估计系数
			reg_time20{j} = reg_temp1(length(reg_temp1)-1); % time20的估计系数
			
			sheet_name2 = strcat("总面板回归截距_",num2str(ii+9),"_行业", num2str(j));
			reg_temp2 = xlsread(regfile, sheet_name2);
			reg_int{j} = reg_temp2(:,1);
			
			mydata.log_pgdp{j} = log(mydata.GDP{j}./mydata.POP{j});
			mydata.log_pcap{j} = log(mydata.CAP{j}./mydata.POP{j});
		end
		for j = 1:4
			for col = 1:31
				mydata.IND_alpha{j}(1,col) = reg_alpha{j};
				% 第一种办法：用2020年的pgdp和pcap数据，代入alpha值算出Zt，记得加上time的影响额度，formula <- log(pgdp) ~ 1 + time + log(pcap)
				Zt_old = exp(mydata.log_pgdp{j}(21,col) - reg_alpha{j}*mydata.log_pcap{j}(21,col) - reg_time20{j} + reg_time20{j}); 
				%第二种办法：用原始数据去计算Zt
				Zt_new = mydata.GDP{j}(21,col) * mydata.CAP{j}(21,col)^(-reg_alpha{j}) * mydata.POP{j}(21,col)^(reg_alpha{j}-1);
				Zt_reg = exp(reg_int{j}(col,1)); % 第三种办法：plm回归结果的截距
				mydata.IND_Zt{j}(1,col) = Zt_new;
			end
		end
	elseif reg_method == 1 % 第一种回归方法：log(Yt/Lt) ~ Z+t*dZ + alpha*log(Kt/Lt)
		if smooth_method == 0
			for j = 1:4
				mydata.log_pgdp{j} = log(mydata.GDP{j}./mydata.POP{j});
				mydata.log_pcap{j} = log(mydata.CAP{j}./mydata.POP{j});
			end
		elseif smooth_method == 1 % 平滑处理，1代表移动平均平滑
			for j = 1:4
				for col = 1:31
					mydata.log_pgdp{j}(:,col) = movmean(log(mydata.GDP{j}(:,col)./mydata.POP{j}(:,col)), [5 5]);
					mydata.log_pcap{j}(:,col) = movmean(log(mydata.CAP{j}(:,col)./mydata.POP{j}(:,col)), [5 5]);
				end
			end
		elseif smooth_method == 2 % 平滑处理，2代表移动中位数平滑
			for j = 1:4
				for col = 1:31
					mydata.log_pgdp{j}(:,col) = movmedian(log(mydata.GDP{j}(:,col)./mydata.POP{j}(:,col)), [5 5]);
					mydata.log_pcap{j}(:,col) = movmedian(log(mydata.CAP{j}(:,col)./mydata.POP{j}(:,col)), [5 5]);
				end
			end
		end

		% ii是指每年的Zt和alpha数据是用之前多少年来估计的
		for j = 1:22-ii
			reg_result{1} = zeros(3,31);
			reg_result{2} = zeros(3,31);
			reg_result{3} = zeros(3,31);
			reg_result{4} = zeros(3,31);
			for i = 1:31
				for nind = 1:4
					time = j:j+ii-1;
					X = [ones(ii, 1), time', mydata.log_pcap{nind}(j:j+ii-1,i)];
					reg_result{nind}(:,i) = regress( mydata.log_pgdp{nind}(j:j+ii-1,i), X);
				%	if reg_result{nind}(2,i) > 0.8 % 为了数据的使用，设置最大alpha为0.8
				%		reg_result{nind}(2,i) = 0.8;
				%	elseif reg_result{nind}(2,i) < 0.3
				%		reg_result{nind}(2,i) = 0.3;
				%	end
				end
			end
			%% 注意回归的系数第一项是截距，也即log(Zt)，第二项是alpha，第三项beta=1-alpha
			%% 当前技术算法：Zt = exp(Z+t*dZ)
			for nind = 1:4
				mydata.IND_Z0{nind}(j,:) = reg_result{nind}(1,:);
				mydata.IND_alpha{nind}(j,:) = reg_result{nind}(2,:);
				mydata.IND_beta{nind}(j,:) = ones(size(reg_result{nind}(2,:))) - reg_result{nind}(2,:);
				mydata.IND_Zgrowth{nind}(j,:) = exp(reg_result{nind}(3,:));
				mydata.IND_Zt{nind}(j,:) = exp(mydata.IND_Z0{nind}(j,:) + j*mydata.IND_Zgrowth{nind}(j,:))
			end
		end
		% 循环后保存输入的超参数

	elseif reg_method == 2 % 第二种回归方法：log(Yt) ~ log(Zt) + alpha*log(Kt) + beta*log(Lt)
		reg_result{1} = zeros(3,31);
		reg_result{2} = zeros(3,31);
		reg_result{3} = zeros(3,31);
		reg_result{4} = zeros(3,31);
		if smooth_method == 0 % 不平滑
			for j = 1:4
				for col = 1:31
					mydata.log_Yt{j}(:,col) = log(mydata.GDP{j}(:,col));
					mydata.log_Lt{j}(:,col) = log(mydata.POP{j}(:,col));
					mydata.log_Kt{j}(:,col) = log(mydata.CAP{j}(:,col));
				end
			end
		elseif smooth_method == 1 % 平滑处理，1代表移动平均平滑
			for j = 1:4
				for col = 1:31
					mydata.log_Yt{j}(:,col) = movmean(log(mydata.GDP{j}(:,col)), [5 5]);
					mydata.log_Lt{j}(:,col) = movmean(log(mydata.POP{j}(:,col)), [5 5]);
					mydata.log_Kt{j}(:,col) = movmean(log(mydata.CAP{j}(:,col)), [5 5]);
				end
			end
		elseif smooth_method == 2 % 平滑处理，2代表移动中位数平滑
			for j = 1:4
				for col = 1:31
					mydata.log_Yt{j}(:,col) = movmedian(log(mydata.GDP{j}(:,col)), [5 5]);
					mydata.log_Lt{j}(:,col) = movmedian(log(mydata.POP{j}(:,col)), [5 5]);
					mydata.log_Kt{j}(:,col) = movmedian(log(mydata.CAP{j}(:,col)), [5 5]);
				end
			end
		end
		for i = 1:31
			for nind = 1:4
				for j = 1:22-ii
				time = j:j+ii-1;
				X = [ones(size(mydata.log_Yt{nind}(j:j+ii-1,i))), time', mydata.log_Kt{nind}(j:j+ii-1,i), mydata.log_Lt{nind}(j:j+ii-1,i)];
				reg_result{nind}(:,i) = regress( mydata.log_Yt{nind}(j:j+ii-1,i),  [ones(size(mydata.log_Yt{nind}(j:j+ii-1,i))) mydata.log_Kt{nind}(j:j+ii-1,i) mydata.log_Lt{nind}(j:j+ii-1,i)] );
				end
			end
		end
		%% 注意回归的系数第一项是截距，也即log(Zt)，第二项是alpha
		for nind = 1:4
			mydata.IND_Zt{nind}(j,:) = exp(reg_result{nind}(1,:));
			mydata.IND_alpha{nind}(j,:) = reg_result{nind}(2,:);
			mydata.IND_beta{nind}(j,:) = reg_result{nind}(3,:);
		end
	end
	% 循环后保存输入的超参数
	mydata.GDP_multiplier = GDP_multiplier;
	mydata.POP_multiplier = POP_multiplier;
	mydata.delta = delta;
	%% 本循环的数据储存到最终输出变量中
	mydata2{ii} = mydata;
end
%%% 保存到指定文件，加速下次的读取。
save(reg_file,'mydata2');
end

toc
