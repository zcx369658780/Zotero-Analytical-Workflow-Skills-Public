function Lt_mat = Lt_seperate(results, param, phi_mat, sigmau_MAT, N_prov)
% 这个函数专门拆解并计算家户部门的劳动迁移结果
Lt_mat = zeros(N_prov,N_prov);
for i = 1:N_prov
	for j = 1:N_prov
	% Lt_mat(j,i)代表的是省份i的家户去省份j工作的平均个人时长，因此最后要乘以省份i的人口规模
	Lt_mat(j,i) = results{i}.Ct^(-param.ga/param.phi_l) * (results{j}.wjt * (1-results{i}.tau - sigmau_MAT(j,i))/phi_mat(j,i))^(1/param.phi_l);
	if isreal(Lt_mat(j,i)) == 0
		disp(['Lt_mat(j,i) = ',num2str(Lt_mat(j,i))])
		disp(['相关参数：sigmau_MAT, phi_mat, paramphi_l, results.wjt, 以及((results{j}.wjt * (1-results{i}.tau - sigmau_MAT(j,i))/phi_mat(j,i)))=', num2str(sigmau_MAT(j,i)), ', ', num2str(phi_mat(j,i)), ', ', num2str(param.phi_l), ', ', num2str(results{j}.wjt), ', 以及 ', num2str((results{j}.wjt * (1-results{i}.tau - sigmau_MAT(j,i))/phi_mat(j,i))), ', ', num2str(results{i}.Ct)])
		error('Lt_mat计算出现虚数！')
	end
	end
	Lt_mat(:,i) = Lt_mat(:,i) * results{i}.N; % 要乘以各省的人口规模
	%disp(["检查Lt综合：Lt_total/Lt_sum=", num2str(results{i}.Lt*results{i}.N), ' / ', num2str(sum(Lt_mat(:,i),'all'))])
end


