%%% 2023年12月6日 多省份神经网络HANK模型主程序
%%% 这个程序调用其他程序并且完成画图。

clear all; close all; clc;
global Ncores; Ncores = 1;
global myfontsize; myfontsize = 14;
global N_prov; N_prov = 31;
maxyear = 15; % 2009-2023年
%NIRFs = N_prov;
NIRFs = 8;
T = 20;
[all_themes, all_colors] = GetColors(); % 使用自定义色表
for j = 1:NIRFs
	shock{j}.T = T;
	shock{j}.NIRFs = NIRFs;
	shock{j}.epsilon_sigmau = zeros(T,1);
	for i = 1:N_prov
		shock{j}.epsilon_z{i} = zeros(T,1);
		shock{j}.epsilon_gv{i} = zeros(T,1);
		shock{j}.epsilon_tauw{i} = zeros(T,1);
		shock{j}.epsilon_tauf{i} = zeros(T,1);
		shock{j}.epsilon_pi{i} = zeros(T,1);
	end
end

%show_prv = [1, 9, 19, 16, 27];
show_prv = [1, 9, 11, 19, 16, 12, 14, 24];

for i = 1:4
	shocks{i} = shock;
	shocks{i}{1}.NIRFs = NIRFs;
end

shocks_policy = shock;

% 综合政策模拟有5个冲击，分别是：减税，降低利率，供给侧改革提高生产力，区域融合发展降低迁移成本，以及这四个冲击合起来。政策模拟只跑4期（一年，每一期一个季度）


shocknames_policy = {};
for k= 1:maxyear
	shocknames_policy{k} = strcat('综合政策冲击_',num2str(k+2008));
end

	Tvec = 1:T; shockrange = 0.01; shockvar = 0.5;
	shockseries =(shockrange)* exp(-(1-shockvar)*(Tvec-1));

shocknames = {'生产力冲击';'国有资产冲击';'工资税率冲击';'扩张货币政策'};
shocks_policy_name = {'减税政策';'宽松货币政策';'供给侧改革政策';'区域融合发展政策';'综合政策模拟'};

% 演示的冲击变量与省份
IRF_vars = {"Yt","Ct","Lt","Kt","ra"};
	for i = 1:length(show_prv) % 节省时间，只跑5个省份的冲击
		shocks{1}{i}.epsilon_z{show_prv(i)} = shockseries; % 前31个冲击是生产力冲击
		shocks{2}{i}.epsilon_gv{show_prv(i)} = shockseries; % 后31个冲击是政府投资的冲击
		shocks{3}{i}.epsilon_tauw{show_prv(i)} = shockseries; % 然后是工资税率冲击
		shocks{4}{i}.epsilon_pi{show_prv(i)} = shockseries*0.1; % 扩张性货币政策
	end
	for i = 1:N_prov
		shocks_policy{1}.NIRFs = 5;
		shocks_policy{1}.epsilon_tauw{i} = -shockseries;
		shocks_policy{1}.epsilon_tauf{i} = -shockseries;
		shocks_policy{2}.epsilon_pi{i} = -0.1*shockseries;
		shocks_policy{3}.epsilon_z{i} = shockseries;
		shocks_policy{4}.epsilon_sigmau = -shockseries;
		shocks_policy{5}.epsilon_tauw{i} = -shockseries;
		shocks_policy{5}.epsilon_tauf{i} = -shockseries;
		shocks_policy{5}.epsilon_pi{i} = -0.1*shockseries;
		shocks_policy{5}.epsilon_z{i} = shockseries;
		shocks_policy{5}.epsilon_sigmau = -shockseries;
	end


%% IRF{3}{ishow_prv}里面存放的是第三种、工资税率冲击中，第二个展示省份，也即实际上第九个省发生冲击的全部变量

% 定义五种颜色的RGB值，和R语言那边的颜色风格保持一致。
	custom_colors = [  
    0.0000 0.2412 0.4510; % #003973  
    0.0000 0.4235 0.1725; % #006d2c  
    1.0000 0.4980 0.0000; % #ff7f00  
    0.4118 0.0000 0.6588; % #6a00a8  
    0.6980 0.1098 0.1843; % #b2182b  
];  

%% 2009-2020，连续12年的稳态图
runsts = 1;
if runsts == 1
	if isempty(gcp('nocreate'))
		parpool(Ncores);
	end
	parfor i = 1:maxyear
	%for i = 1:maxyear
		%sts{i} = multi_prov_HANK_12sts(i,1);
		sts{i} = multi_prov_HANK_12sts(i,0);
	end

	%error('st test!')

	for i = 1:N_prov
		Ytvec{i} = zeros(maxyear, 1);
		Ktvec{i} = zeros(maxyear, 1);
		Ltvec{i} = zeros(maxyear, 1);
		Ctvec{i} = zeros(maxyear, 1);
		ravec{i} = zeros(maxyear, 1);
	end

	for i = 1:N_prov
		for iyear = 1:maxyear
			Ytvec{i}(iyear) = sts{iyear}.results{i}.Yt/sts{1}.results{i}.Yt-1;
			Ctvec{i}(iyear) = sts{iyear}.results{i}.Ct_total/sts{1}.results{i}.Ct_total-1;
			Ltvec{i}(iyear) = sts{iyear}.results{i}.Lt/sts{1}.results{i}.Lt-1;
			Ktvec{i}(iyear) = sts{iyear}.results{i}.Kt/sts{1}.results{i}.Kt-1;
			ravec{i}(iyear) = sts{iyear}.results{i}.ra/sts{1}.results{i}.ra-1;
		end
	end

	close all;
	h = figure(1);
	Tvec12 = 2009:2023;
	set(h, 'name', '12prov sts');
		set(gcf,'color','white'); 
		set(gca, 'FontName','arial','FontSize', myfontsize, 'FontWeight', 'bold', 'ColorOrder', custom_colors); hold all;
		tiledlayout('flow','TileSpacing','compact','Padding','compact');

	for i = 1:N_prov
		nexttile
		plot(Tvec12, Ytvec{i}, Tvec12, Ctvec{i}, Tvec12, Ltvec{i}, Tvec12, Ktvec{i}, Tvec12, ravec{i}, 'LineWidth', 2); 
		set(gca, 'ColorOrder', custom_colors);
		grid on;grid minor;title(sts{1}.results{i}.prvname,'FontSize', myfontsize)
	end
	
	nexttile
	plot(Tvec12, zeros(maxyear,1), Tvec12, zeros(maxyear,1), Tvec12, zeros(maxyear,1), Tvec12, zeros(maxyear,1), Tvec12, zeros(maxyear,1), 'LineWidth', 2); 
	set(gca, 'ColorOrder', custom_colors);
	legend("产出Yt","消费Ct","劳动供给Lst","资本供给Kst", "资产回报率ra", 'FontSize', myfontsize-4)
	grid on;grid minor;title('2009-2020年稳态值增长率','FontSize', myfontsize)

		warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
		jFrame = get(h,'JavaFrame');
		pause(0.7);
		set(jFrame,'Maximized',1);
		pause(0.7);
		warning('on','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');

		exportgraphics(h,'2009-2020年稳态值变化图.png','Resolution',96); 
	close all;
	else
	for i = 1:maxyear
		sts{i} = multi_prov_HANK_12sts(i,0);
	end
end
%% 保存各省每年的稳态值和实际值
save_stYt = 1;
if save_stYt == 1
	Yt_file = "12年稳态值.xlsx";
	if exist(Yt_file) ~= 2
		delete(Yt_file);
	end
	for i = 1:N_prov
		prov_names{i} = sts{12}.results{i}.prvname;
	end
	for jj = 1:6
		MyMat{jj} = zeros(31,12);
	end
	for iyear = 1:maxyear
		yearnum{iyear} = num2str(iyear+2008);
		for iprv = 1:N_prov
			MyMat{1}(iprv,iyear) = sts{iyear}.results{iprv}.Yt0 / sts{iyear}.param.GDP_multiplier;
			MyMat{2}(iprv,iyear) = sts{iyear}.results{iprv}.Yt / sts{iyear}.param.GDP_multiplier;
			MyMat{3}(iprv,iyear) = sts{iyear}.results{iprv}.Kt0 / sts{iyear}.param.GDP_multiplier;
			MyMat{4}(iprv,iyear) = sts{iyear}.results{iprv}.Kt / sts{iyear}.param.GDP_multiplier;
			MyMat{5}(iprv,iyear) = sts{iyear}.results{iprv}.N / sts{iyear}.param.POP_multiplier;
			MyMat{6}(iprv,iyear) = sts{iyear}.results{iprv}.Lt / sts{iyear}.param.POP_multiplier;
		end
	end
	Matnames = {"Yt0","Yt","Kt0","Kt","Lt0","Lt"};
	for jj = 1:6
		sheetname1 = strcat("稳态值_",Matnames{jj});
		T1 = array2table(MyMat{jj}, 'VariableNames', yearnum);
		prov_names_col = cell2table(prov_names', 'VariableNames', {'省份'});
		T1 = [prov_names_col, T1];
		writetable(T1, Yt_file, 'Sheet', sheetname1, 'WriteMode', 'append');
	end
end



%error("sts test")

%% 将稳态的劳动力迁移矩阵保存到excel中
%% 注意，Ltmat固定保存在第31个省份的results中
for i = 1:N_prov
	prov_names{i} = sts{1}.results{i}.prvname;
end
if exist("12年稳态Ltmat.xlsx") == 2
	delete("12年稳态Ltmat.xlsx")
end
for iyear = 1:maxyear
	Ltmat_save(prov_names, sts{iyear}.results{31}.Lt_mat, "12年稳态Ltmat.xlsx", strcat(num2str(iyear+2008),'年'));
end

%error("sts test")

%%% 读取稳态 后从这里开始跑，手动复制可以避免重复读取。




%% 单个冲击的图
run_irf = 1;
	if run_irf == 1
		if isempty(gcp('nocreate'))
			parpool(Ncores);
		end
		parfor k = 1:4
			[IRF{k}, st2{k}] = multi_prov_HANK(shocks{k}, shocknames{k}, 2020, 0);
		end
		parfor k = 1:maxyear
			[IRF_policy{k}, st3{k}] = multi_prov_HANK(shocks_policy, shocknames_policy{k}, 2008+k, 0);
		end
	end
%error('冲击响应完毕')
%st = multi_prov_HANK_12sts(12,0);
st = st2{4};

%% 政策模拟图，IRF_policy只有4期的长度，用于模拟一年的冲击
% 正常的全国IRF，2020年
for ishock = 1:5 % 5种冲击
	h = figure(ishock);
		h = figure(ishock);
		set(h, 'name', '政策IRF');
		set(gcf,'color','white'); 
		set(gca, 'FontName','arial','FontSize', myfontsize, 'FontWeight', 'bold', 'ColorOrder', custom_colors); hold all;
		tiledlayout('flow','TileSpacing','compact','Padding','compact');

	for iprv = 1:N_prov % 31个省份
		nexttile
		for ivar = 1:length(IRF_vars) % 看这几个变量
			vars = IRF_vars{ivar};
			for iyear = maxyear:maxyear % 只看最后一年的IRF
				for time = 1:T % 4期
					var_vec{ivar}(time) = eval(strcat("IRF_policy{iyear}{ishock}{time}{iprv}. ",vars," / st3{iyear}.results{iprv}.",vars," - 1"));
				end
			end
		end


		plot(Tvec, var_vec{1}, Tvec, var_vec{2}, Tvec, var_vec{3}, Tvec, var_vec{4}, Tvec, var_vec{5}, 'LineWidth', 2); 
		set(gca, 'ColorOrder', custom_colors);
		grid on;grid minor;title(st.results{iprv}.prvname,'FontSize', myfontsize)
	end
	
	nexttile
	plot(Tvec, zeros(T,1), Tvec, zeros(T,1), Tvec, zeros(T,1), Tvec, zeros(T,1), Tvec, zeros(T,1), 'LineWidth', 2); 
	set(gca, 'ColorOrder', custom_colors);
	legend("产出Yt","消费Ct","劳动供给Lst","资本供给Kst", "资产回报率ra", 'FontSize', myfontsize-4)
	grid on;grid minor;title(strcat('冲击：',shocks_policy_name{ishock}),'FontSize', myfontsize)

		warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
		jFrame = get(h,'JavaFrame');
		pause(0.7);
		set(jFrame,'Maximized',1);
		pause(0.7);
		warning('on','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');

		exportgraphics(h,strcat('政策模拟IRF_',shocks_policy_name{ishock},'.png'),'Resolution',96); 
		%error("IRF test")
		close all;
end

% 下面这个是全部政策12年效果加总
for ishock = 1:5 % 5种冲击
	h = figure(ishock);
	set(h, 'name', '政策12年效果');
	set(gcf,'color','white'); 
	set(gca, 'FontName','arial','FontSize', myfontsize, 'FontWeight', 'bold', 'ColorOrder', custom_colors); hold all;
	tiledlayout('flow','TileSpacing','compact','Padding','compact');
	for iprv = 1:N_prov % 31个省份
		nexttile
		varMAT = zeros(maxyear,length(IRF_vars));
		for ivar = 1:length(IRF_vars) % 看这几个变量
			vars = IRF_vars{ivar};
			for iyear = 1:maxyear % 每个省份统计12年稳态各自4期的冲击结果
				tempvec = zeros(4,1);
				for time = 1:4 % 4期
					tempvec(time) = eval(strcat("IRF_policy{iyear}{ishock}{time}{iprv}. ",vars," / st3{iyear}.results{iprv}.",vars," - 1"));
				end
				varMAT(iyear,ivar) = sum(tempvec, 'all');
			end
		end
		plot(2009:2023, varMAT, 'LineWidth', 2); 
		set(gca, 'ColorOrder', custom_colors);
		grid on;grid minor;title(st.results{iprv}.prvname,'FontSize', myfontsize)
	end




	
	nexttile
	plot(2009:2023, zeros(maxyear,1), 2009:2023, zeros(maxyear,1), 2009:2023, zeros(maxyear,1), 2009:2023, zeros(maxyear,1), 2009:2023, zeros(maxyear,1), 'LineWidth', 2); 
	set(gca, 'ColorOrder', custom_colors);
	legend("产出Yt","消费Ct","劳动供给Lst","资本供给Kst", "资产回报率ra", 'FontSize', myfontsize-4)
	grid on;grid minor;title(strcat('政策模拟:',shocks_policy_name{ishock}),'FontSize', myfontsize)
		warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
		jFrame = get(h,'JavaFrame');
		pause(0.7);
		set(jFrame,'Maximized',1);
		pause(0.7);
		warning('on','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');

		exportgraphics(h,strcat('政策模拟12年_',shocks_policy_name{ishock},'.png'),'Resolution',96); 
		%error("IRF test")
		close all;
end

% 最后是五等分图。只画第12年的。
mytheme = all_themes{1};
quantile_vars = {"C","l"} % 只画消费和劳动的五等分图
quantile_vars2 = {"消费","劳动"} 
for ishock = 1:5 % 5种冲击
	for ivar = 1:length(quantile_vars)
		h = figure(j);
		set(h, 'name', '政策模拟五等分');
		set(gcf,'color','white'); 
		set(gca, 'FontName','arial','FontSize', myfontsize, 'FontWeight', 'bold', 'ColorOrder', mytheme); hold all;
		tiledlayout('flow','TileSpacing','compact','Padding','compact');


	for i = 1:N_prov
		nexttile 
		for iyear = maxyear:maxyear % 12年，每年的五等分前四期都加起来
			quantilevec = HANK_quantile5_multiprov(IRF_policy{iyear}{ishock}, i, st.results{i}, quantile_vars{ivar}, T);
		end
		plot(Tvec, quantilevec,'LineWidth', 2);
		set(gca, 'ColorOrder', mytheme);
		grid on;grid minor;title(st.results{i}.prvname,'FontSize', 12)
	end
	
	nexttile
	plot(Tvec, zeros(T,5), 'LineWidth', 2); 
	set(gca, 'ColorOrder', mytheme);
	legend('前20%', '20%-40%', '40%-60%', '60%-80%', '80%-100%', 'FontSize', 9)
	grid on;grid minor;title(strcat(quantile_vars2{ivar},'五等分：',shocks_policy_name{ishock}),'FontSize', 10)

		warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
		jFrame = get(h,'JavaFrame');
		pause(0.7);
		set(jFrame,'Maximized',1);
		pause(0.7);
		warning('on','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');

		exportgraphics(h,strcat('政策模拟五等分',quantile_vars2{ivar},'_',shocks_policy_name{ishock},'.png'),'Resolution',96); 
		%error('IRF test')
		close all;
	end
end


%error('政策冲击test！')

%% 演示用的IRF
for shockprov = 1:length(show_prv)
	for j = 1:3
		h = figure(j);
		set(h, 'name', 'SingleIRFs');
		set(gcf,'color','white'); 
		set(gca, 'FontName','arial','FontSize', myfontsize, 'FontWeight', 'bold', 'ColorOrder', custom_colors); hold all;
		tiledlayout('flow','TileSpacing','compact','Padding','compact');

	for i = 1:N_prov
		nexttile % 每种冲击，每个省份一个图。
		for ivar = 1:length(IRF_vars)
			vars = IRF_vars{ivar};
			for time = 1:T
				var_vec{ivar}(time) = eval(strcat("IRF{j}{shockprov}{time}{i}. ",vars," / st.results{i}.",vars," - 1"));
			end
		end

		plot(Tvec, var_vec{1}, Tvec, var_vec{2}, Tvec, var_vec{3}, Tvec, var_vec{4}, Tvec, var_vec{5}, 'LineWidth', 2); 
		set(gca, 'ColorOrder', custom_colors);
		grid on;grid minor;title(st.results{i}.prvname,'FontSize', myfontsize)
	end
	
	nexttile
	plot(Tvec, zeros(T,1), Tvec, zeros(T,1), Tvec, zeros(T,1), Tvec, zeros(T,1), Tvec, zeros(T,1), 'LineWidth', 2); 
	set(gca, 'ColorOrder', custom_colors);
	legend("产出Yt","消费Ct","劳动供给Lst","资本供给Kst", "资产回报率ra", 'FontSize', myfontsize-4)
	grid on;grid minor;title(strcat('冲击：',shocknames{j}),'FontSize', myfontsize)

		warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
		jFrame = get(h,'JavaFrame');
		pause(0.7);
		set(jFrame,'Maximized',1);
		pause(0.7);
		warning('on','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');

		exportgraphics(h,strcat('省份IRF_',shocknames{j},'_',st.results{show_prv(shockprov)}.prvname,'.png'),'Resolution',96); 
		%error("IRF test")
		close all;
	end
end
%error("IRF test")

%% IRF影响的弹性，也即某个省份冲击变量1个百分点引起其他省份变化的百分比。
%% 分为加总百分比，和最高百分比两种影响。都算。
%% 需要注意，矩阵的第j行是冲击发生在第j个省份后，对所有省份的影响。也即，扣除(j,j)位置后这一行的变量都是第j个省份冲击对其他省份的影响。

for k = 1:3
	for ivar = 1:length(IRF_vars)
		coef_total_mat{k}{ivar} = zeros(N_prov,N_prov); % 存放系数的矩阵
	end
end

for k = 1:3 % 3类冲击
	for ivar = 1:length(IRF_vars) % 受到影响的5种变量
		vars = IRF_vars{ivar};
		for shockprov = 1:NIRFs % 只计算5个冲击
			var_vec2 = zeros(T,1);
			for i = 1:N_prov % 对31个省的影响
				for time = 1:T
					var_vec2(time) = eval(strcat("IRF{k}{shockprov}{time}{i}.",vars,"/ st.results{i}.",vars," - 1"));
				end
				if k == 1 || k == 2 || k == 3
					sumshock = sum(shockseries);
				elseif k == 4
					sumshock = sum(-0.1*shockseries);
				end
				coef_total_mat{k}{ivar}(show_prv(shockprov),i) = sum(var_vec2) / sumshock;
			end
		end
	end
end

coef_file1 = "31x3冲击的影响系数矩阵.xlsx";
if exist(coef_file1) ~= 2
	for i = 1:N_prov
		prov_names{i} = st.results{i}.prvname;
	end
	for k = 1:3
		for ivar = 1:length(IRF_vars)
			sheetname1 = strcat("总冲击系数",num2str(k),"_",IRF_vars{ivar});
			%sheetname2 = strcat("最大冲击系数",num2str(k),"_",IRF_vars{ivar});
			T1 = array2table(coef_total_mat{k}{ivar}, 'VariableNames', prov_names);   % 存放系数的矩阵
			%T2 = array2table(coef_max_mat{k}{ivar}, 'VariableNames', prov_names);   % 存放系数的矩阵
			%T1 = insertvars(T1, 1, '省份', cell2table(prov_names'))
			prov_names_col = cell2table(prov_names', 'VariableNames', {'省份'});  
			T1 = [prov_names_col, T1];  
			%T2 = [prov_names_col, T2];  
			% 使用 writetable 函数写入 Excel 文件  
			if k == 1 && ivar == 1  % 如果这是第一个工作表，则创建一个新的 Excel 文件  
				writetable(T1, coef_file1, 'Sheet', sheetname1);  
				%writetable(T2, coef_file1, 'Sheet', sheetname2, 'WriteMode', 'append');  
			else  % 对于后续的工作表，使用 append 模式  
				writetable(T1, coef_file1, 'Sheet', sheetname1, 'WriteMode', 'append');  
				%writetable(T2, coef_file1, 'Sheet', sheetname2, 'WriteMode', 'append');  
			end  
			
		end
	end
end

error("输出地图IRF用的excel完毕")

%% 家户五等分图，只做劳动和消费。

mytheme = all_themes{1};
quantile_vars = {"C","l"} % 只画消费和劳动的五等分图
quantile_vars2 = {"消费","劳动"} 
for ishock = show_prv
	shockindex = find(show_prv==ishock);
	for j = 1:3
		for ivar = 1:length(quantile_vars)
		h = figure(j);
		set(h, 'name', 'SingleIRFs');
		set(gcf,'color','white'); 
		set(gca, 'FontName','arial','FontSize', myfontsize, 'FontWeight', 'bold', 'ColorOrder', mytheme); hold all;
		tiledlayout('flow','TileSpacing','compact','Padding','compact');

	for i = 1:N_prov
		nexttile % 每个省份五等分画在一起
		quantilevec = HANK_quantile5_multiprov(IRF{j}{shockindex}, i, st.results{i}, quantile_vars{ivar}, T);
		plot(Tvec, quantilevec, 'LineWidth', 2); 
		set(gca, 'ColorOrder', mytheme);
		grid on;grid minor;title(strcat(st.results{i}.prvname,':',num2str(st.results{i}.inter_prv_ratio)),'FontSize', 12)
	end
	
	nexttile
	plot(Tvec, zeros(5,T), 'LineWidth', 2); 
	set(gca, 'ColorOrder', mytheme);
	legend('前20%', '20%-40%', '40%-60%', '60%-80%', '80%-100%', 'FontSize', 9)
	grid on;grid minor;title(strcat(quantile_vars2{ivar},'五等分：', st.results{ishock}.prvname,shocknames{j}),'FontSize', 10)

		warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
		jFrame = get(h,'JavaFrame');
		pause(0.7);
		set(jFrame,'Maximized',1);
		pause(0.7);
		warning('on','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');

		exportgraphics(h,strcat('五等分',quantile_vars2{ivar},'_',shocknames{j},'_',st.results{ishock}.prvname,'.png'),'Resolution',96); 
		%error('IRF test')
		close all;
		end
	end
end




%%% 连续12年冲击的变化
%%% 这个图的运算量是最大的，即使精简了冲击规模大约也要跑上3个小时
%%% 先做技术和货币政策这两个冲击的，也即1和4

	run_irf = 1;
	if run_irf == 1
		if isempty(gcp('nocreate'))
			parpool(Ncores);
		end
		parfor iyear = 1:maxyear
			[IRFZt{iyear}, sts{iyear}] = multi_prov_HANK(shocks{1}, shocknames{1}, iyear+2008, 0);
			[IRFGovInv{iyear}, sts{iyear}] = multi_prov_HANK(shocks{2}, shocknames{2}, iyear+2008, 0);
			[IRFtauw{iyear}, sts{iyear}] = multi_prov_HANK(shocks{3}, shocknames{3}, iyear+2008, 0);
			[IRFit{iyear}, sts{iyear}] = multi_prov_HANK(shocks{4}, shocknames{4}, iyear+2008, 0);
		end
	end


% 12年总冲击的衡量画图
Yearvec = 2009:2023; close all;
for j = [1,4]
		h = figure(j);
		set(h, 'name', 'yearIRFs');
		set(gcf,'color','white'); 
		set(gca, 'FontName','arial','FontSize', myfontsize, 'FontWeight', 'bold', 'ColorOrder', all_themes{2}); hold all;
		tiledlayout('flow','TileSpacing','compact','Padding','compact');

	for i = 1:N_prov
		nexttile 
		% 每种冲击，每个省份一个图。横坐标是年份，纵坐标是这一年总冲击幅度。一共5根线，分别代表5个省份的冲击在这12年稳态下的对其他省份总冲击变动。
		for shockprov = 1:length(show_prv)
			for iyear = 1:maxyear
				tempvec = zeros(T,1);
				for itime = 1:T
					if j == 1 % 技术冲击
						tempvec(itime) = IRFZt{iyear}{shockprov}{itime}{i}.Yt / sts{iyear}.results{i}.Yt;
						sumshock = sum(shockseries);
					elseif j == 4 %
						tempvec(itime) = IRFit{iyear}{shockprov}{itime}{i}.Yt / sts{iyear}.results{i}.Yt -1;
						sumshock = sum(-0.1*shockseries);
					end
				end
				var_yvec{shockprov}(iyear) = sum(tempvec, 'all') / sumshock;
				%var_yvec{shockprov}(iyear) = max(tempvec);
			end
		end

		plot(Yearvec, var_yvec{1}, Yearvec, var_yvec{2}, Yearvec, var_yvec{3}, Yearvec, var_yvec{4}, Yearvec, var_yvec{5}, 'LineWidth', 2); 
		set(gca, 'ColorOrder', all_themes{2});
		grid on;grid minor;title(sts{1}.results{i}.prvname,'FontSize', myfontsize)
	end
	
	nexttile
	plot(Yearvec, zeros(maxyear,1), Yearvec, zeros(maxyear,1), Yearvec, zeros(maxyear,1), Yearvec, zeros(maxyear,1), Yearvec, zeros(maxyear,1), 'LineWidth', 2); 
	set(gca, 'ColorOrder', all_themes{2});
	legend(sts{1}.results{show_prv(1)}.prvname,sts{1}.results{show_prv(2)}.prvname,sts{1}.results{show_prv(3)}.prvname,sts{1}.results{show_prv(4)}.prvname,sts{1}.results{show_prv(5)}.prvname, 'FontSize', myfontsize-4)
	grid on;grid minor;title(strcat('12年总冲击影响:',shocknames{j}),'FontSize', myfontsize-2)

		warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
		jFrame = get(h,'JavaFrame');
		pause(0.7);
		set(jFrame,'Maximized',1);
		pause(0.7);
		warning('on','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');

		exportgraphics(h,strcat('12年冲击对比_',shocknames{j},'_',sts{1}.results{show_prv(shockprov)}.prvname,'.png'),'Resolution',96); 
		%error("IRF test")
		close all;
end


































