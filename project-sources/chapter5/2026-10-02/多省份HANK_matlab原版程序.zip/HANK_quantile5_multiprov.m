function quantileVec = HANK_quantile5_multiprov(IRF, iprov, st, varname, T)
%% 这个程序通过调用HANK_quantile.m计算一个变量与分布的5个quantile。
%% 输入：存放变量名varname和分布g的冲击IRF，存放稳态的st，冲击持续时间长度T
%% 输出：一个矩阵，一共5行。第一行存放的是前20%财富值家户的变量quantile值，在1到T时间点上的序列。第二行是前21%-40%，以此类推。
%% 2024年5月30日修改：给多省份模型用，IRF的结构变了。
	stvec = eval(strcat('st.',varname));
	sttemp = HANK_quantileg(st.g, stvec, st.g, st.aaah, 2, [0.2, 0.4, 0.6, 0.8, 1]);
	results = zeros(5,T);
	for i = 1:T
		valuevec = eval(strcat('IRF{i}{iprov}.',varname));
		IRFg = IRF{i}{iprov}.g;
		temp = HANK_quantileg(IRFg, valuevec, st.g, st.aaah, 2, [0.2, 0.4, 0.6, 0.8, 1]);
		results(1,i) = temp(1)/sttemp(1) - 1; % 第一行是财富值最高的20%
		results(2,i) = (temp(2) - temp(1))/(sttemp(2) - sttemp(1)) - 1; % 次高的20%，也就是财富值降序排列时21%-40%的家户
		results(3,i) = (temp(3) - temp(2))/(sttemp(3) - sttemp(2)) - 1;
		results(4,i) = (temp(4) - temp(3))/(sttemp(4) - sttemp(3)) - 1;
		results(5,i) = (temp(5) - temp(4))/(sttemp(5) - sttemp(4)) - 1;
	end

quantileVec = results;
end