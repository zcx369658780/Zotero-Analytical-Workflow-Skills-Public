function st = multi_prov_HANK_12sts(ii, pp)
%% 2023年12月6日 多省份神HANK的求解程序
%%% 主要用途为调用其他子函数完成多省份神经网络HANK模型的计算
%%% 返回的结果就是模型模拟结果。
%%% 2024年3月16日 新推导了模型结构，暂时去掉
global Ncores;
global myfontsize;
global N_prov; N_prov = 31;
warning('off');

%%% Initialization

%% convergence thresholds
num.maxit= 100;
num.crit = 10^(-7);
num.reg_threshold = 10^(-9);
%num.homecrit = 10^(-2);
num.homecrit = 10^(-2);
num.Delta = 1000;
num.maxiter = 100;
num.max2iter = 200;
num.max3iter = 500;

%% transaction cost
%CHI.chi0 = 0.01;
CHI.chi0 = 0.1;
CHI.chi1 = 2;
%CHI.a_bar = 10^(-3);
CHI.a_bar = 0.000001;
CHI.fixcost = 0;
CHI.fixcost2 = 0;

%% grids
grid.I			=	20; % 流动性资产b格点参数
%grid.bmin		=	-2;
grid.bmin		=	-2;
%grid.bmax		=	5;
grid.bmax		=	5;
grid.J			=	20; % 固定资产a的格点参数
grid.amin 		=	0; 
%grid.amax 		=	10;
grid.amax 		=	10;
grid.Nz			=	2; % 个人能力z的格点参数
grid.zmin		=	0.8; 
grid.zmax		=	1.3; 
grid.z			=	linspace(grid.zmin, grid.zmax, grid.Nz);
grid.la_mat		=	ones(grid.Nz,grid.Nz)*(1/3/(grid.Nz-1)) + eye(grid.Nz,grid.Nz)*(-1/3-1/3/(grid.Nz-1));%% lambda转移矩阵。

%grid.ramax		=	0.065;
grid.ramax		=	0.09;
%grid.ramin		=	0.01;
grid.ramin		=	0.02;
%grid.wjtmax		=	1;
grid.wjtmax		=	1.3;
grid.wjtmin		=	0.8;



%% HANK model parameters
param.ga		=	2; % 家户，效用函数的消费风险厌恶系数。
param.phi_l		=	5; % 家户，农村劳动弗里茨弹性的倒数
param.alphal	=	1; % 家户，总劳动相对厌恶系数
param.alphap	=	1; % 家户，总消费相对厌恶系数
param.frisch_l	=	0.2; % 家户，农村劳动弗里茨弹性
param.rho		=	0.05; % 家户效用的折现率
param.rho_pi	=	1.25; % 银行，泰勒公式的通胀系数
param.epsilon	=	10; % 厂商，中间品公司替代弹性参数
param.theta		=	100; % 厂商，Rotemberg价格粘性, epsilon/theta = 0.1是菲利普斯曲线的斜率。
param.delta		=	0.025; % 厂商，资本折旧率
param.istar		=	0.015; % 银行，目标名义利率。
param.pistar	=	0.0075; % 银行，目标通胀
param.max_phi	=	0.3; % 劳动偏好厌恶系数，决定人均gdp高的地区去低的地区的厌恶程度
param.max_sigmau	=	0.5; % 地理距离计算迁移成本的系数。

	%% 下面几个是数据读取的参数
	%smooth_method = 1; % 移动平均平滑
	param.smooth_method = 0; % 使用原始数据，不平滑
	%reg_method = 1; % 使用人均法估计技术和资本弹性
	param.reg_method = 0; % 使用R语言面板估计的方法获得alpha，并且反向推导Zt值
	%param.GDP_multiplier=1000; param.POP_multiplier = 100; % 比较好的一个版本
	param.GDP_multiplier=1000; param.POP_multiplier = 100;
	param.Ztratio = 1; % 初始Zt大小
	param.GovInv_ratio = 1; % 资本存量数据中，有多少比例是政府资本（固定投资），剩余的比例就是家户资产转化的。注意这个只是初始值，为了模型收敛后续会自动调整。

init.alpha 	=	0.6; % 厂商，柯布道格拉斯资本参与率
init.rb_gap	=	0.07; % 流动性资产欠款利率和rb的差值
init.rah		=	0.09; % 家户的固定资产回报率 
init.ra		=	0.09; % 
init.it			=	0.02; % 名义利率
init.rb			=	0.02; % 非流动性资产回报率 
init.rk			=	0.1; % 非流动性资产回报率 
init.wjt			=	0.6; % 非流动性资产回报率 
init.w			=	20; % 本省工资初始值
init.Tt		=	0.1; % 转移支付
init.Zt		=	6; % 初始生产力，由于现实数据估计结果不稳定只能默认某个值了。
init.pit	=	0.02; % 默认通胀率
init.pit_1	=	0.02; % 默认通胀率
init.totalpit	=	0.02; % 默认通胀率
init.epsilon_pi	=	0; % 冲击变量
init.tau	=	0.05; % 默认工资税率
init.At	=	2;
init.Bt	=	1;
init.mt	=	0.9;
init.Lt	=	0.8;
init.Ct	=	4;
init.GovInv	=	1000;
init.GovSurplus	=	0;
init.inter_prv_ratio	=	0.5; % 每个省的家户持有外省资本的比例
init.Lt_mat	=	zeros(N_prov,N_prov); % 劳动迁移矩阵
init.corptau	=	0.25; % 厂商，毛利润税率
for i = 1:N_prov
	inits{i} = init;
	grids{i} = grid;
end



year = ii+2008;
stfile = strcat('Multi_Province_12sts_',num2str(year),'.mat');
% 读取数据，判断当前剩余计算任务。
if exist(stfile) == 2
	disp(['发现稳态数据文件: ', stfile,', 读取稳态数据...'])
	temp2 = struct2cell(load(stfile,'st'));
	st = temp2{1};
	%save(stfile, 'st', '-v7.3');
else
	%% 读取数据。现在读取的是所有年份的数据了
	data_MAT = load_GDPdata(param.GDP_multiplier, param.POP_multiplier,0.096, param.smooth_method, param.reg_method);
	% 2023年12月17日更新：添加了一二三产业的数据，估计了三个产业的Zt和alpha，并且填补了缺失数据。
	% 2024年4月28日更新： 使用张军的方法估计数据。
	% 2024年5月3日更新： 放弃一二三产业，改用R语言的CHNCapitalStock包提供的各省年度资本存量数据，并且省级数据的人口采用常住人口
	% 2024年6月1日更新：现在采用前10年的数据估计本年的alpha，也即2000-2009年的数据可以估计出2009年的alpha。
	st = mpHANK_equilibrium_2000(param,grids,num,CHI,inits,data_MAT{ii}, 4, ii);save(stfile, 'st', '-v7.3');
	
end

% 检查各省的稳态分布，画图。
if pp > 0
	Plot_multiprv_g(st, N_prov, strcat("多省份稳态分布图_",num2str(year)));
	close all;
end


