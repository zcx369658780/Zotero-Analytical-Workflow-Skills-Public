function Gini=Gini_coef2(pp, NumArr, Ntitle)

NumArrSorted=sort([0,NumArr]);

NumArrPercent=NumArrSorted/sum(NumArrSorted);

NumArrSortedLen=length(NumArrSorted);

NumArrAcc=zeros(1,NumArrSortedLen);

for i=1:NumArrSortedLen

    NumArrAcc(i)=sum(NumArrPercent(1:i));

end

x1=linspace(0,1,NumArrSortedLen);

x2=0:(1/NumArrSortedLen/10):1;

cfithandle=fit(x1',NumArrAcc','smoothingspline');

d=cfithandle(x2);


if pp>0
	h = figure(pp);
	set(h, 'name', Ntitle);
	set(gca,'FontSize',10)
	plot(x1,x1,'b-',x1,NumArrAcc,'r--',x2,d,'m.')
	
	

	title('The Lorenz curve','FontSize',10,'interpreter','latex')

	xlabel('Cumulative percentage of population ','FontSize',10,'interpreter','latex')

	ylabel('Cumulative percentage of income','FontSize',10,'interpreter','latex')

	axis equal

	axis([0,1,0,1])

	grid on
end


area1=trapz(x2,d);

area2=trapz(x1,x1);

Gini=round(1-area1/area2,4);

end