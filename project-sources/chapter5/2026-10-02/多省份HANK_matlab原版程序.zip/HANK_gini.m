function Gini = HANK_gini(pp, g, value, asset, varname)
%% compute gini coef
%% input： pp - draw pic; g - distribution matrix; asset - asset matrix, for sorting distribution; value - value matrix, for computing Gini coef;varname - for plotting;
	I = prod(size(g));

	allasset = reshape(asset, [I 1]);
	disvec = reshape(g, [I 1]);
	valuevec = reshape(value.*g, [I 1]);

	[sortAllasset, sortIndex] = sort(allasset, 'ascend'); 
	sortdis = disvec(sortIndex);
	sortAsset = valuevec(sortIndex);

	Allasset = sum(asset.*g, 'all'); 
	Aggregated_asset = zeros(I,1);
	for i = 1:I
		Aggregated_asset(i) = sum(sortAsset(1:i),'all') / Allasset;
	end

	Gini=Gini_coef2(pp, Aggregated_asset', varname);
end