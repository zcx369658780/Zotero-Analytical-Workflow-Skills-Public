function wt_vec = wage_caculate(results, param, phi_l_mat, sigmau_MAT, N_prov)
% 论文中的平均工资计算
wt_vec = zeros(N_prov,1);
for i = 1:N_prov
	temp = 0;

	for j = 1:N_prov
		temp = temp + phi_l_mat(j,i)*(results{j}.wjt*(1 - results{j}.tau - sigmau_MAT(j,i))/phi_l_mat(j,i))^(1+1/param.phi_l);
	end
	
	wt_vec(i) = param.alphal^(-param.phi_l/(1+param.phi_l)) * temp^(param.phi_l/(1+param.phi_l));
	if isreal(wt_vec(i)) == 0 || wt_vec(i)<0
		disp(['wt_vec(i) = ',num2str(wt_vec(i))])
		disp(['alphal, phi_l, phi_l_mat(j,i), temp=', num2str(param.alphal), ', ', num2str(param.phi_l), ', ', num2str(phi_l_mat(j,i)), ', ', num2str(temp)])
		error('wt_vec计算出错！')
	end
end


