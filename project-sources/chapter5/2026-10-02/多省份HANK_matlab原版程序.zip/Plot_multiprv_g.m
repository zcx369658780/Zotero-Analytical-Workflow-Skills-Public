function IRFresult=Plot_multiprv_g(st, N_prov, savefile)
myfontsize = 12;
	close all;
	h = figure(1);
	set(h, 'name', '多省份稳态图');
	set(gcf,'color','white'); 
	set(gca, 'FontName','arial','FontSize', 10, 'FontWeight', 'bold'); hold all;
	tiledlayout('flow','TileSpacing','compact','Padding','compact');
	
	for i = 1:N_prov
		nexttile
		set(gca,'FontSize',10)
		VV = sum(st.results{i}.g, [3]);
		VV = reshape(VV, st.grids{i}.I, st.grids{i}.J);
		mesh(VV)
		set(gca,'YTicklabel',st.grids{i}.bmin:(st.grids{i}.bmax-st.grids{i}.bmin)/4:st.grids{i}.bmax);
		set(gca,'XTicklabel',st.grids{i}.amin:(st.grids{i}.amax-st.grids{i}.amin)/4:st.grids{i}.amax);
		ylabel('Bt')
		xlabel('At')
		title(st.results{i}.prvname)
	end



		warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
		jFrame = get(h,'JavaFrame');
		pause(0.7);
		set(jFrame,'Maximized',1);
		pause(0.7);
		warning('on','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');

		exportgraphics(h,strcat(savefile,'.png'),'Resolution',96); 


IRFresult = 2;
end