function quantileVars = HANK_quantileg(g, value, st_g, st_aaah, assetdim, quantiles)
%% compute variable value of aggregated top quantile percentage of Deposit.
%% input： g - distribution matrix; value - variable matrix; asset - asset matrix; assetdim - the dimision of asset in V(b,ah,af,z); quantiles - top percent series for qunatiles;
	I = prod(size(g));
	size_g = size(g); size_g(assetdim) = [];
	
	allasset = reshape(st_aaah, [I 1]);
	disvec = reshape(st_g, [I 1]);
	valuevec = reshape(value.*g, [I 1]);

	[sortAllasset, sortIndex] = sort(allasset, 'descend'); % 降序意味着从value最高的人开始计数，算的是value最高的10%的人。
	sortdis = disvec(sortIndex);
	sortAsset = valuevec(sortIndex);
	quantileVars = zeros(1,length(quantiles));
	nq = 1;
	temp = 0;
	for quantileKey = 1:I
		temp = temp + sortdis(quantileKey);
		
		if temp >= quantiles(nq) % 累计分布超出第nq个的值时
			%disp(["目前quantile计数为 ",num2str(nq),", 目前总体进度为 ",num2str(temp)])
			quantileVars(nq) = sum(sortAsset(1:quantileKey), 'all');
			nq = nq + 1; 
		end
			%totaltest1 = sum(sortAsset(1:quantileKey), 'all');
			%totaltest2 = sum(sortAsset(1:I), 'all');
		if nq > length(quantiles) % 前4个可以检测阈值，最后一个直接加总所有的即可。
			break;
		end
	end
	quantileVars(length(quantiles)) = sum(sortAsset(1:I), 'all');
	%disp("检测quantile结算结果:")
	%disp(quantileVars)
	%disp(["总值为：", num2str(totaltest1), ' / ', num2str(totaltest2)])
end