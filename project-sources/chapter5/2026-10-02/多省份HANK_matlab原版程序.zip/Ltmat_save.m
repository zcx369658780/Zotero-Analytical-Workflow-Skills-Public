function T1 = Ltmat_save(prvnames, Ltmat, excelfile, sheetname)
	% 将Ltmat保存到指定excel文件的指定sheet中
	% 行名称为省份名
	T1 = array2table(Ltmat, 'VariableNames', prvnames);
	disp(strcat('正在保存数据_',sheetname,'......'))
	if exist(excelfile) == 2
		writetable(T1, excelfile, 'Sheet', sheetname, 'WriteMode', 'append');
	else
		writetable(T1, excelfile, 'Sheet', sheetname);
	end
end


