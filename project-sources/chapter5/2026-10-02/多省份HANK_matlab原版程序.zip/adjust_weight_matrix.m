function wmat = adjust_weight_matrix(wmat_old, GDP, GDP_real, lrate)
% 调整权重矩阵的程序
% 输入：当前的权重矩阵，实际的GDP序列，目前的GDP序列
% 输出：调整后的权重矩阵
% 算法说明：如果某个省份的GDP超过了实际GDP一个百分点，则降低所有其他省对这个省的权重值lrate个百分点，反之亦然。最后标准化后作为返回结果
	change_rate = GDP./GDP_real - 1;
	nprov = length(GDP);
	wmat2 = wmat_old;
	for i = 1:nprov
		wmat2(:,i) = wmat_old(:,i) * (change_rate(i) * lrate);
	end
	wmat = normalize_weight_matrix(wmat2);
